"use client";
import { useState, useEffect, useRef, useMemo, createContext, useContext } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X, UserPlus, MessageCircle, Send, Check, ArrowLeft, Handshake, Zap,
  BookOpen, CheckCircle2, Circle, Loader2, Users, Settings, Clock, Target, ShieldCheck,
} from "lucide-react";
import {
  friendshipId, sendFriendRequestByEmail, sendFriendRequestToUid, listAllUsers,
  listenIncomingRequests, listenOutgoingRequests,
  acceptFriendRequest, declineFriendRequest, cancelFriendRequest, listenFriendships,
  listenFriendState, listenChatMessages, sendChatMessage,
} from "@/lib/friendsStorage";
import { MemoriesModal, normalizeScopeTheme, fontStackFor, formatTime12 } from "@/components/BTLDashboard";

/* ---- Friend Celebration theme (Settings -> Theme -> Friend Celebration) ----
   Same {bg,text,font,bold,scale} shape as the app's other theme scopes
   (see normalizeScopeTheme in BTLDashboard.jsx). Provided via context so
   every nested view (hub, VS intro, VS split-screen, chat) can pick up
   the chosen colors/size/font without threading props through each one. */
const FRIEND_THEME_DEFAULT = {
  bg: "linear-gradient(145deg,#1b1a17,#252422)",
  text: "#fff",
  fontFamily: undefined,
  bold: false,
  scale: 1,
};
const FriendThemeCtx = createContext(FRIEND_THEME_DEFAULT);
function useFriendTheme() { return useContext(FriendThemeCtx); }

/* ---- "Liquid Glassic" theme (this update) ----
   Setting -> Theme -> Friend Celebration -> "Liquid Glassic" toggle
   (ScopeThemeEditor's `friendPreset` option, BTLDashboard.jsx) turns on
   this fixed look, ONLY inside Friend Celebration (hub, VS split-screen,
   chat popup) — nothing else in the app changes. Soft neumorphic/
   liquid-glass cards on a light canvas, every word rendered in black,
   and every %/streak/score number plus money figure keeps its own
   accent color so it still reads at a glance against the light card. */
const GLASSIC_TOKENS = {
  pageBg: "linear-gradient(160deg,#eef0f3 0%,#e6e9ee 55%,#dfe3ea 100%)",
  text: "#1c1c1e",
  muted: "rgba(28,28,30,0.55)",
  faint: "rgba(28,28,30,0.3)",
  cardBg: "rgba(255,255,255,0.55)",
  cardBorder: "1px solid rgba(255,255,255,0.8)",
  cardShadow: "8px 8px 18px rgba(163,177,198,0.45), -8px -8px 18px rgba(255,255,255,0.85)",
  innerBg: "rgba(255,255,255,0.55)",
  innerBorder: "1px solid rgba(209,213,219,0.55)",
  chipBg: "rgba(0,0,0,0.05)",
  inputBg: "rgba(255,255,255,0.8)",
  inputBorder: "1px solid rgba(190,196,206,0.9)",
  ringTrack: "rgba(28,28,30,0.1)",
  blur: "blur(22px) saturate(180%)",
  earnColor: "#2e7d32",
  spendColor: "#c0392b",
};

/* ============================================================
   FRIEND CELEBRATION
   Header icon (wired in BTLDashboard.jsx) opens this full-screen
   panel. Flow:
     intro    -> a "VS" style clash animation plays every time this
                 opens (not just first time — it's the panel's own
                 entrance effect)
     hub      -> your name, an "Invite a Friend" box (by email),
                 incoming requests (accept/decline), outgoing
                 (pending) requests, and your existing friends list
     vsIntro  -> a second VS animation (this time with the real
                 friend's photo) plays when you open a friend, or
                 automatically the moment they accept your invite
                 while you're sitting on the hub
     vs       -> the split-screen "You vs {Friend}" dashboard, with
                 a Chat button (glass popup, live) and a Memory
                 button on the friend's side (reuses the exact same
                 MemoriesModal the rest of the app uses, fed with
                 their live data via Firestore)
   ============================================================ */

const C = { bg: "#fffcf2", text: "#403d39", dark: "#252422", accent: "#fca311", blue: "#98c1d9" };

/* ---------------- small shared bits ---------------- */

function Avatar({ name, photoURL, size = 48 }) {
  const initial = (name || "?").trim().charAt(0).toUpperCase();
  return photoURL ? (
    <img
      src={photoURL} alt={name || "Avatar"} referrerPolicy="no-referrer"
      style={{ width: size, height: size, borderRadius: "50%", objectFit: "cover", display: "block", flexShrink: 0, boxShadow: "0 4px 16px rgba(0,0,0,0.35)" }}
    />
  ) : (
    <div style={{
      width: size, height: size, borderRadius: "50%", background: C.accent, color: "#fff", flexShrink: 0,
      display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.4, fontWeight: 800,
      boxShadow: "0 4px 16px rgba(0,0,0,0.35)",
    }}>
      {initial}
    </div>
  );
}

function MiniRing({ pct = 0, size = 42, color = C.accent, label }) {
  const ft = useFriendTheme();
  const p = Math.min(100, Math.max(0, pct || 0));
  const r = (size - 6) / 2;
  const circ = 2 * Math.PI * r;
  const off = circ - (p / 100) * circ;
  // On Liquid Glassic the ring sits on a light card, so the number reads
  // in the ring's own accent color (not the fixed white used on dark cards).
  const numberColor = ft.glassic ? color : "#fff";
  const trackColor = ft.glassic ? GLASSIC_TOKENS.ringTrack : "rgba(255,255,255,0.14)";
  const labelColor = ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.6)";
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
      <div style={{ position: "relative", width: size, height: size }}>
        <svg width={size} height={size} style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }}>
          <circle cx={size / 2} cy={size / 2} r={r} stroke={trackColor} strokeWidth={4} fill="none" />
          <motion.circle
            cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={4} fill="none" strokeLinecap="round"
            strokeDasharray={circ} initial={{ strokeDashoffset: circ }} animate={{ strokeDashoffset: off }}
            transition={{ type: "spring", stiffness: 70, damping: 16 }}
          />
        </svg>
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.24, fontWeight: 900, color: numberColor }}>
          {Math.round(p)}%
        </div>
      </div>
      {label && <div style={{ fontSize: 8.5, fontWeight: 800, color: labelColor }}>{label}</div>}
    </div>
  );
}

function computeStatsFromState(state) {
  if (!state) return null;
  const dailyPct = state.dailyGoals?.length ? (state.dailyGoals.filter((g) => g.done).length / state.dailyGoals.length) * 100 : 0;
  const extryPct = state.extryGoals?.length ? (state.extryGoals.filter((g) => g.done).length / state.extryGoals.length) * 100 : 0;
  const overallPct = (dailyPct + extryPct) / 2;
  const streak = state.streak || 0;
  const lifeScore = Math.round(dailyPct * 0.35 + extryPct * 0.25 + Math.min(streak / 30, 1) * 100 * 0.4);
  return { dailyPct, extryPct, overallPct, streak, lifeScore };
}

/* ---------------- VS intro animation (fullscreen) ---------------- */

function VSIntro({ leftPhoto, leftName, rightPhoto, rightName, onDone }) {
  const ft = useFriendTheme();
  const introText = ft.glassic ? "#fff" : ft.text; // stays legible on the colored diagonal split either way
  useEffect(() => {
    const t = setTimeout(onDone, 1500);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <motion.div
      key="vs-intro"
      initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.4 }}
      style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}
    >
      <motion.div initial={{ x: "-100%" }} animate={{ x: 0 }} transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
        style={{ position: "absolute", inset: 0, background: "linear-gradient(135deg,#e63946,#fca311)", clipPath: "polygon(0 0, 55% 0, 45% 100%, 0 100%)" }} />
      <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
        style={{ position: "absolute", inset: 0, background: "linear-gradient(315deg,#252422,#403d39)", clipPath: "polygon(55% 0, 100% 0, 100% 100%, 45% 100%)" }} />

      <motion.div initial={{ x: -240, opacity: 0, scale: 0.6 }} animate={{ x: -90, opacity: 1, scale: 1 }}
        transition={{ delay: 0.3, type: "spring", stiffness: 210, damping: 16 }} style={{ position: "relative", zIndex: 1 }}>
        <Avatar name={leftName} photoURL={leftPhoto} size={104} />
      </motion.div>
      <motion.div initial={{ x: 240, opacity: 0, scale: 0.6 }} animate={{ x: 90, opacity: 1, scale: 1 }}
        transition={{ delay: 0.3, type: "spring", stiffness: 210, damping: 16 }} style={{ position: "relative", zIndex: 1 }}>
        <Avatar name={rightName} photoURL={rightPhoto} size={104} />
      </motion.div>

      <motion.div
        initial={{ scale: 0, opacity: 0 }} animate={{ scale: [0, 1.4, 1], opacity: [0, 1, 1] }}
        transition={{ delay: 0.72, duration: 0.5, times: [0, 0.6, 1] }}
        style={{ position: "absolute", zIndex: 2, fontSize: Math.round(44 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: introText, fontStyle: "italic", letterSpacing: 2, textShadow: "0 0 30px rgba(255,255,255,0.85), 0 4px 20px rgba(0,0,0,0.5)" }}
      >VS</motion.div>
      <motion.div
        initial={{ scale: 0, opacity: 0.9 }} animate={{ scale: 3.2, opacity: 0 }}
        transition={{ delay: 0.72, duration: 0.6, ease: "easeOut" }}
        style={{ position: "absolute", width: 56, height: 56, borderRadius: "50%", background: "radial-gradient(circle, rgba(255,255,255,0.95), transparent 70%)", zIndex: 1 }}
      />

      <div style={{ position: "absolute", bottom: 46, fontSize: Math.round(12 * ft.scale), fontWeight: ft.bold ? 900 : 800, color: introText, opacity: 0.8, letterSpacing: 1 }}>
        🎉 Friend Celebration
      </div>
    </motion.div>
  );
}

/* ---------------- HUB: your name, invite, requests, friends ---------------- */

const STATUS_MSG = {
  not_found: "Koi user is email se nahi mila — pehle unhe BTL mein sign in karna hoga.",
  self: "Aap khud ko invite nahi kar sakte 🙂",
  already_friends: "Aap already friends hain!",
  already_sent: "Request pehle se bheji ja chuki hai.",
  error: "Kuch galat ho gaya, dobara try karein.",
};

function FriendHubView({ user, friendships, incoming, outgoing, onSelectFriend, onClose, onOpenThemeSettings }) {
  const ft = useFriendTheme();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState(null);
  const [sending, setSending] = useState(false);
  const [busyId, setBusyId] = useState(null);

  const [allUsers, setAllUsers] = useState(null); // null = loading
  const [discoverErr, setDiscoverErr] = useState(false);
  const [discoverSentIds, setDiscoverSentIds] = useState(() => new Set());
  const [discoverStatus, setDiscoverStatus] = useState({}); // uid -> {ok, reason}

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    listAllUsers(user.uid)
      .then((list) => { if (!cancelled) setAllUsers(list); })
      .catch(() => { if (!cancelled) { setAllUsers([]); setDiscoverErr(true); } });
    return () => { cancelled = true; };
  }, [user]);

  // Anyone already a friend, or with a pending request either way, is
  // filtered out of "Discover" — no point showing a button for them there,
  // they already live in Friends / Requests / Sent.
  const friendUids = useMemo(() => new Set(friendships.map((f) => f.otherUid)), [friendships]);
  const pendingUids = useMemo(
    () => new Set([...incoming.map((r) => r.fromUid), ...outgoing.map((r) => r.toUid)]),
    [incoming, outgoing]
  );
  const discoverList = useMemo(
    () => (allUsers || []).filter((u) => !friendUids.has(u.uid) && !pendingUids.has(u.uid) && !discoverSentIds.has(u.uid)),
    [allUsers, friendUids, pendingUids, discoverSentIds]
  );

  const send = async () => {
    if (!email.trim() || sending) return;
    setSending(true); setStatus(null);
    try {
      const res = await sendFriendRequestByEmail(user, email.trim());
      setStatus(res);
      if (res.ok) setEmail("");
    } catch (e) {
      setStatus({ ok: false, reason: "error" });
    }
    setSending(false);
  };

  const sendToDiscoverUser = async (target) => {
    setBusyId(target.uid);
    try {
      const res = await sendFriendRequestToUid(user, target);
      setDiscoverStatus((s) => ({ ...s, [target.uid]: res }));
      if (res.ok) setDiscoverSentIds((s) => new Set(s).add(target.uid));
    } catch (e) {
      setDiscoverStatus((s) => ({ ...s, [target.uid]: { ok: false, reason: "error" } }));
    } finally {
      setBusyId(null);
    }
  };

  const withBusy = (id, fn) => async () => { setBusyId(id); try { await fn(); } finally { setBusyId(null); } };

  return (
    <motion.div
      key="hub"
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
      transition={{ type: "spring", stiffness: 260, damping: 26 }}
      style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", padding: "22px 26px 14px" }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <Avatar name={user?.displayName || user?.email} photoURL={user?.photoURL} size={46} />
        <div>
          <div style={{ fontSize: Math.round(17 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text }}>{user?.displayName || user?.email || "You"}</div>
          <div style={{ fontSize: Math.round(11 * ft.scale), color: ft.text, opacity: 0.6, fontWeight: ft.bold ? 800 : 700 }}>🎉 Friend Celebration</div>
        </div>
        <div style={{ flex: 1 }} />
        {/* Friend Celebration theme shortcut — jumps straight to
            Setting -> Theme -> Friend Celebration instead of making the
            user close this popup and click through the tabs themselves. */}
        <motion.button whileHover={{ scale: 1.1, rotate: 25 }} whileTap={{ scale: 0.9 }} onClick={onOpenThemeSettings} title="Friend Celebration theme"
          style={{ background: ft.glassic ? GLASSIC_TOKENS.chipBg : "rgba(255,255,255,0.12)", border: "none", borderRadius: "50%", width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", color: ft.glassic ? GLASSIC_TOKENS.text : "#fff", cursor: "pointer" }}>
          <Settings size={16} />
        </motion.button>
        <motion.button whileHover={{ scale: 1.1, rotate: 90 }} whileTap={{ scale: 0.9 }} onClick={onClose}
          style={{ background: ft.glassic ? GLASSIC_TOKENS.chipBg : "rgba(255,255,255,0.12)", border: "none", borderRadius: "50%", width: 34, height: 34, display: "flex", alignItems: "center", justifyContent: "center", color: ft.glassic ? GLASSIC_TOKENS.text : "#fff", cursor: "pointer" }}>
          <X size={17} />
        </motion.button>
      </div>

      <div style={{ flex: 1, minHeight: 0, overflowY: "auto", marginTop: 22, display: "flex", flexDirection: "column", gap: 22 }} className="btl-scroll">
        {/* invite */}
        <div style={{
          background: ft.glassic ? GLASSIC_TOKENS.cardBg : "rgba(255,255,255,0.08)",
          backdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(14px) saturate(150%)",
          WebkitBackdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(14px) saturate(150%)",
          borderRadius: 16, padding: 16,
          border: ft.glassic ? GLASSIC_TOKENS.cardBorder : "1px solid rgba(255,255,255,0.14)",
          boxShadow: ft.glassic ? GLASSIC_TOKENS.cardShadow : "none",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 10 }}>
            <UserPlus size={15} color={C.accent} />
            <span style={{ fontSize: 13, fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.text : "#fff" }}>Invite a Friend</span>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input
              value={email} onChange={(e) => { setEmail(e.target.value); setStatus(null); }}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="friend's email address..."
              style={{
                flex: 1, fontSize: 12, padding: "10px 12px", borderRadius: 10, outline: "none",
                border: ft.glassic ? GLASSIC_TOKENS.inputBorder : "1px solid rgba(255,255,255,0.18)",
                background: ft.glassic ? GLASSIC_TOKENS.inputBg : "rgba(255,255,255,0.08)",
                color: ft.glassic ? GLASSIC_TOKENS.text : "#fff",
              }}
            />
            <motion.button whileHover={{ y: -1 }} whileTap={{ scale: 0.94 }} onClick={send} disabled={sending}
              style={{ border: "none", background: C.accent, color: "#fff", borderRadius: 10, padding: "0 16px", fontWeight: 800, fontSize: 12, cursor: "pointer", display: "flex", alignItems: "center", gap: 6, opacity: sending ? 0.7 : 1 }}>
              {sending ? <Loader2 size={13} className="btl-spin" /> : <Send size={13} />} Invite
            </motion.button>
          </div>
          <AnimatePresence>
            {status && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                style={{ marginTop: 8, fontSize: 11, fontWeight: 700, color: status.ok ? "#7bd389" : "#f4a261", overflow: "hidden" }}>
                {status.ok ? "✅ Invite sent!" : STATUS_MSG[status.reason] || STATUS_MSG.error}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* incoming requests */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.65)", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5 }}>
            Requests {incoming.length > 0 && `(${incoming.length})`}
          </div>
          {incoming.length === 0 && <div style={{ fontSize: 11, color: ft.glassic ? GLASSIC_TOKENS.faint : "rgba(255,255,255,0.4)" }}>Koi naya friend request nahi hai.</div>}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <AnimatePresence>
              {incoming.map((req) => (
                <motion.div key={req.id} layout initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 12 }}
                  style={{ display: "flex", alignItems: "center", gap: 10, background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.08)", borderRadius: 12, padding: "9px 12px" }}>
                  <Avatar name={req.fromName} photoURL={req.fromPhoto} size={34} />
                  <div style={{ fontSize: Math.round(12 * ft.scale), fontWeight: ft.bold ? 900 : 800, color: ft.text, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{req.fromName}</div>
                  <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} disabled={busyId === req.id}
                    onClick={withBusy(req.id, () => acceptFriendRequest(req))}
                    style={{ background: "#4a7c59", border: "none", borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", cursor: "pointer" }}>
                    <Check size={14} />
                  </motion.button>
                  <motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }} disabled={busyId === req.id}
                    onClick={withBusy(req.id, () => declineFriendRequest(req.id))}
                    style={{ background: "rgba(230,57,70,0.85)", border: "none", borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", cursor: "pointer" }}>
                    <X size={14} />
                  </motion.button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* outgoing */}
        {outgoing.length > 0 && (
          <div>
            <div style={{ fontSize: 11, fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.65)", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5 }}>Sent</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {outgoing.map((req) => (
                <div key={req.id} style={{ display: "flex", alignItems: "center", gap: 10, background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.05)", borderRadius: 12, padding: "9px 12px" }}>
                  <Avatar name={req.toName} photoURL={req.toPhoto} size={28} />
                  <div style={{ fontSize: 11.5, fontWeight: 700, color: ft.glassic ? GLASSIC_TOKENS.text : "rgba(255,255,255,0.75)", flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    Waiting for {req.toName || "a reply"}...
                  </div>
                  <motion.button whileTap={{ scale: 0.9 }} disabled={busyId === req.id}
                    onClick={withBusy(req.id, () => cancelFriendRequest(req.id))}
                    style={{ background: "transparent", border: "none", color: ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.5)", fontSize: 10, fontWeight: 700, cursor: "pointer" }}>
                    Cancel
                  </motion.button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* discover — every other user on the dashboard, request them directly */}
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 8 }}>
            <Users size={13} color={ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.65)"} />
            <span style={{ fontSize: 11, fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.65)", textTransform: "uppercase", letterSpacing: 0.5 }}>
              Discover {allUsers && discoverList.length > 0 && `(${discoverList.length})`}
            </span>
          </div>
          {allUsers === null && (
            <div style={{ fontSize: 11, color: ft.glassic ? GLASSIC_TOKENS.faint : "rgba(255,255,255,0.4)", display: "flex", alignItems: "center", gap: 6 }}>
              <Loader2 size={12} className="btl-spin" /> Users load ho rahe hain...
            </div>
          )}
          {discoverErr && <div style={{ fontSize: 11, color: "#c0392b" }}>Users list load nahi ho payi, dobara try karein.</div>}
          {allUsers !== null && !discoverErr && discoverList.length === 0 && (
            <div style={{ fontSize: 11, color: ft.glassic ? GLASSIC_TOKENS.faint : "rgba(255,255,255,0.4)" }}>Abhi koi naya user dikhne ke liye nahi hai.</div>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <AnimatePresence>
              {discoverList.map((u) => {
                const st = discoverStatus[u.uid];
                return (
                  <motion.div key={u.uid} layout initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 12 }}
                    style={{ display: "flex", flexDirection: "column", gap: 4, background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.06)", borderRadius: 12, padding: "9px 12px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <Avatar name={u.name} photoURL={u.photoURL} size={32} />
                      <div style={{ fontSize: Math.round(12 * ft.scale), fontWeight: ft.bold ? 900 : 800, color: ft.text, flex: 1, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.name}</div>
                      <motion.button whileHover={{ y: -1 }} whileTap={{ scale: 0.94 }} disabled={busyId === u.uid}
                        onClick={() => sendToDiscoverUser(u)}
                        style={{ border: "none", background: C.accent, color: "#fff", borderRadius: 999, padding: "5px 12px", fontWeight: 800, fontSize: 10.5, cursor: "pointer", display: "flex", alignItems: "center", gap: 5, flexShrink: 0, opacity: busyId === u.uid ? 0.7 : 1 }}>
                        {busyId === u.uid ? <Loader2 size={11} className="btl-spin" /> : <UserPlus size={11} />} Request
                      </motion.button>
                    </div>
                    {st && !st.ok && (
                      <div style={{ fontSize: 10, fontWeight: 700, color: ft.glassic ? "#c0392b" : "#f4a261" }}>{STATUS_MSG[st.reason] || STATUS_MSG.error}</div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </div>

        {/* friends */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.65)", marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5 }}>
            Your Friends {friendships.length > 0 && `(${friendships.length})`}
          </div>
          {friendships.length === 0 && <div style={{ fontSize: 11, color: ft.glassic ? GLASSIC_TOKENS.faint : "rgba(255,255,255,0.4)" }}>Abhi tak koi friend nahi — upar se invite bhejein.</div>}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(110px, 1fr))", gap: 12, paddingBottom: 10 }}>
            {friendships.map((f) => (
              <motion.div key={f.id} whileHover={{ y: -4, scale: 1.03 }} whileTap={{ scale: 0.97 }} onClick={() => onSelectFriend(f)}
                style={{
                  cursor: "pointer", borderRadius: 14, padding: "14px 8px", display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
                  background: ft.glassic ? GLASSIC_TOKENS.cardBg : "rgba(255,255,255,0.08)",
                  backdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(14px) saturate(150%)",
                  WebkitBackdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(14px) saturate(150%)",
                  border: ft.glassic ? GLASSIC_TOKENS.cardBorder : "1px solid rgba(255,255,255,0.12)",
                  boxShadow: ft.glassic ? GLASSIC_TOKENS.cardShadow : "none",
                }}>
                <Avatar name={f.name} photoURL={f.photoURL} size={48} />
                <div style={{ fontSize: Math.round(11 * ft.scale), fontWeight: ft.bold ? 900 : 800, color: ft.text, textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", width: "100%" }}>{f.name}</div>
                <div style={{ fontSize: 8.5, fontWeight: 700, color: C.accent, display: "flex", alignItems: "center", gap: 3 }}><Handshake size={10} /> Open</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

/* ---------------- VS split-screen dashboard ---------------- */

/* ---------------- animated done-check (this update) ----------------
   Shared by GoalMiniList and TimeTableMiniList. A plain icon-swap used
   to just flip Circle -> CheckCircle2 with no feedback at all — the
   moment you (or your friend) actually finish something now gets a
   proper "landed" moment: the check springs in with a soft green burst
   ring expanding and fading behind it, instead of silently appearing. */
function DoneCheck({ done, size = 12 }) {
  const ft = useFriendTheme();
  return (
    <span style={{ position: "relative", width: size, height: size, display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <AnimatePresence mode="wait" initial={false}>
        {done ? (
          <motion.span key="done" style={{ position: "relative", display: "flex" }}
            initial={{ scale: 0.3, rotate: -90, opacity: 0 }} animate={{ scale: 1, rotate: 0, opacity: 1 }} exit={{ scale: 0.3, opacity: 0 }}
            transition={{ type: "spring", stiffness: 520, damping: 20 }}>
            <motion.span aria-hidden initial={{ scale: 0.5, opacity: 0.75 }} animate={{ scale: 2.4, opacity: 0 }} transition={{ duration: 0.6, ease: "easeOut" }}
              style={{ position: "absolute", inset: 0, borderRadius: "50%", background: "#2e7d3260", pointerEvents: "none" }} />
            <CheckCircle2 size={size} color="#2e7d32" fill="#c8f5d4" style={{ position: "relative" }} />
          </motion.span>
        ) : (
          <motion.span key="undone" style={{ display: "flex" }} initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.7, opacity: 0 }}>
            <Circle size={size} color={ft.glassic ? "rgba(28,28,30,0.3)" : "rgba(255,255,255,0.35)"} />
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
}

/* ---------------- hover "word bubble" pop (this update) ----------------
   Per feedback: the animated gradient border/fill was too much — reverted
   to a plain static border. Instead, each goal/time-table row now gets a
   speech-bubble style pop when the mouse hovers over it: a soft rounded
   pill background springs in behind the text (scale 0 -> 1, like a chat
   bubble appearing) and the row lifts slightly, purely via framer-motion's
   whileHover (no extra state, no new dependency). */
function BubbleRow({ children, accent, style, onClick }) {
  return (
    <motion.div
      onClick={onClick}
      whileHover={{
        scale: 1.045,
        backgroundColor: `${accent || C.accent}22`,
        boxShadow: `0 3px 10px ${accent || C.accent}40`,
      }}
      transition={{ type: "spring", stiffness: 420, damping: 22 }}
      style={{ borderRadius: 999, cursor: "default", transformOrigin: "left center", ...style }}
    >
      {children}
    </motion.div>
  );
}

function GoalMiniList({ title, items, accent, row }) {
  const ft = useFriendTheme();
  const done = items.filter((g) => g.done).length;
  const acc = accent || C.accent;
  return (
    <div style={{
      background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.05)",
      borderRadius: row ? 6.5 : 12, padding: 10, flexShrink: row ? undefined : 0,
      flex: row ? 1 : undefined, minHeight: 0, minWidth: row ? 0 : undefined,
      maxHeight: row ? undefined : 180, overflowY: row ? "hidden" : "auto",
      display: "flex", flexDirection: "column",
      border: `1.5px solid ${acc}66`, marginLeft: row ? -1.5 : 0,
      height: row ? "100%" : undefined,
    }} className={row ? undefined : "btl-scroll"}>
      <div style={{ fontSize: Math.round(9.5 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text, opacity: row ? 1 : 0.6, marginBottom: 6, flexShrink: 0, display: "flex", flexDirection: row ? "column" : "row", alignItems: row ? "center" : "stretch", gap: row ? 2 : 0, justifyContent: "space-between", textAlign: row ? "center" : "left", paddingBottom: row ? 6 : 0, borderBottom: row ? `1px solid ${acc}44` : "none" }}>
        <span>{title}</span><span>{done}/{items.length}</span>
      </div>
      {items.length === 0 && <div style={{ fontSize: Math.round(10 * ft.scale), color: ft.text, opacity: ft.glassic ? 0.5 : 0.3 }}>No goals yet.</div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 3, ...(row ? { flex: 1, minHeight: 0, overflowY: "auto" } : {}) }} className={row ? "btl-scroll" : undefined}>
        {items.map((g) => (
          <BubbleRow key={g.id} accent={acc}>
            <motion.div layout
              animate={{ background: g.done ? (ft.glassic ? "rgba(46,125,50,0.12)" : "rgba(46,125,50,0.16)") : "rgba(0,0,0,0)" }}
              transition={{ duration: 0.35 }}
              style={{ display: "flex", alignItems: "center", gap: 6, fontSize: Math.round(10.5 * ft.scale), fontWeight: ft.bold ? 700 : 400, color: ft.text, opacity: g.done ? 0.55 : 1, borderRadius: 6, padding: "2px 4px" }}>
              <DoneCheck done={g.done} />
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", textDecoration: g.done ? "line-through" : "none" }}>{g.text || "Goal"}</span>
            </motion.div>
          </BubbleRow>
        ))}
      </div>
    </div>
  );
}

/* ---------------- friend's Time Table (this update) ----------------
   Same card language as GoalMiniList, so it drops into the VS column
   as a third checklist alongside Daily/Extry Goals rather than looking
   bolted on — but with the item's scheduled time shown first (same
   12h format as the main dashboard's Time Table widget) since that's
   the whole point of this list. */
function TimeTableMiniList({ items, accent, row }) {
  const ft = useFriendTheme();
  const list = items || [];
  const done = list.filter((t) => t.done).length;
  const acc = accent || C.accent;
  return (
    <div style={{
      background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.05)",
      borderRadius: row ? 6.5 : 12, padding: 10, flexShrink: row ? undefined : 0,
      flex: row ? 1 : undefined, minHeight: 0, minWidth: row ? 0 : undefined,
      maxHeight: row ? undefined : 180, overflowY: row ? "hidden" : "auto",
      display: "flex", flexDirection: "column",
      border: `1.5px solid ${acc}66`, marginLeft: row ? -1.5 : 0,
      height: row ? "100%" : undefined,
    }} className={row ? undefined : "btl-scroll"}>
      <div style={{ fontSize: Math.round(9.5 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text, opacity: row ? 1 : 0.6, marginBottom: 6, flexShrink: 0, display: "flex", flexDirection: row ? "column" : "row", alignItems: "center", gap: row ? 2 : 0, justifyContent: "space-between", textAlign: row ? "center" : "left", paddingBottom: row ? 6 : 0, borderBottom: row ? `1px solid ${acc}44` : "none" }}>
        <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Clock size={10} /> Time Table</span><span>{done}/{list.length}</span>
      </div>
      {list.length === 0 && <div style={{ fontSize: Math.round(10 * ft.scale), color: ft.text, opacity: ft.glassic ? 0.5 : 0.3 }}>Nothing scheduled yet.</div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 3, ...(row ? { flex: 1, minHeight: 0, overflowY: "auto" } : {}) }} className={row ? "btl-scroll" : undefined}>
        {list.map((t) => (
          <BubbleRow key={t.id || t.time + t.text} accent={acc}>
            <motion.div layout
              animate={{ background: t.done ? (ft.glassic ? "rgba(46,125,50,0.12)" : "rgba(46,125,50,0.16)") : "rgba(0,0,0,0)" }}
              transition={{ duration: 0.35 }}
              style={{ display: "flex", alignItems: "center", gap: 6, fontSize: Math.round(10 * ft.scale), fontWeight: ft.bold ? 700 : 400, color: ft.text, opacity: t.done ? 0.55 : 1, borderRadius: 6, padding: "2px 4px" }}>
              <span style={{ fontSize: Math.round(8.5 * ft.scale), fontWeight: 800, opacity: 0.55, minWidth: 44, flexShrink: 0 }}>{formatTime12(t.time)}</span>
              <DoneCheck done={t.done} />
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", textDecoration: t.done ? "line-through" : "none" }}>{t.text || "Item"}</span>
            </motion.div>
          </BubbleRow>
        ))}
      </div>
    </div>
  );
}

/* ---------------- friend's Life Rules / Life Big Goals (this update) ----------------
   Plain-text reference lists (same shape as the main dashboard's
   TextList — an array of strings, no done state) — so unlike the
   checklists above there's nothing to tick, just their own words
   read back. Reused for both tabs; only the icon + empty-state copy
   differ. */
function TextMiniList({ items, icon: Icon, emptyLabel }) {
  const ft = useFriendTheme();
  const list = items || [];
  return (
    <div style={{ background: ft.glassic ? GLASSIC_TOKENS.innerBg : "rgba(255,255,255,0.05)", borderRadius: 12, padding: 10, flexShrink: 0, maxHeight: 260, overflowY: "auto" }} className="btl-scroll">
      {list.length === 0 && <div style={{ fontSize: Math.round(10 * ft.scale), color: ft.text, opacity: ft.glassic ? 0.5 : 0.3 }}>{emptyLabel}</div>}
      <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
        {list.map((t, i) => (
          <motion.div key={i} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03 }}
            style={{ display: "flex", alignItems: "flex-start", gap: 7, fontSize: Math.round(11 * ft.scale), fontWeight: ft.bold ? 800 : 700, color: ft.text }}>
            <Icon size={12} color={C.accent} style={{ marginTop: 1.5, flexShrink: 0 }} />
            <span>{t}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- per-column view switcher (this update) ----------------
   Per your markup: two extra options — Life Rules and Big Goals — so
   either side of the VS screen can be flipped over to show that
   person's own words instead of just their checklists. A small sliding-
   pill segmented control right above the lists; "Goals" (the default)
   is Daily + Extry + Time Table together, same as before this update,
   just relabeled as one tab now that there's something to switch away
   to. Each PlayerColumn keeps its own tab state, so you can look at
   your Goals while checking your friend's Life Rules side by side. */
const VS_VIEW_TABS = [
  { id: "goals", label: "Goals", icon: CheckCircle2 },
  { id: "rules", label: "Life Rules", icon: ShieldCheck },
  { id: "big", label: "Big Goals", icon: Target },
];
function ViewTabs({ value, onChange, accent }) {
  const ft = useFriendTheme();
  return (
    <div style={{
      display: "flex", gap: 2, padding: 3, borderRadius: 999, flexShrink: 0,
      background: ft.glassic ? "rgba(0,0,0,0.05)" : "rgba(255,255,255,0.06)",
    }}>
      {VS_VIEW_TABS.map((t) => {
        const active = value === t.id;
        return (
          <button key={t.id} onClick={() => onChange(t.id)}
            style={{
              position: "relative", flex: 1, border: "none", background: "transparent", cursor: "pointer",
              padding: "6px 4px", borderRadius: 999, display: "flex", alignItems: "center", justifyContent: "center", gap: 4,
              fontSize: 9, fontWeight: 800, color: active ? "#fff" : (ft.glassic ? GLASSIC_TOKENS.muted : "rgba(255,255,255,0.55)"),
              zIndex: 1,
            }}>
            {active && (
              <motion.span layoutId={`vsTabPill-${accent}`} transition={{ type: "spring", stiffness: 400, damping: 32 }}
                style={{ position: "absolute", inset: 0, borderRadius: 999, background: accent, zIndex: -1 }} />
            )}
            <t.icon size={11} />
            <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

function PlayerColumn({ side, name, photoURL, totalEarn, totalSpend, stats, dailyGoals, extryGoals, timeTable, lifeRules, bigGoals, loading, onOpenMemory }) {
  const ft = useFriendTheme();
  const accent = side === "me" ? C.accent : "#e63946";
  const [view, setView] = useState("goals");
  return (
    <motion.div
      initial={{ opacity: 0, x: side === "me" ? -20 : 20 }} animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 0.1, type: "spring", stiffness: 200, damping: 22 }}
      style={{
        borderRadius: 18, padding: 16, display: "flex", flexDirection: "column", gap: 12, minHeight: 0,
        background: ft.glassic ? GLASSIC_TOKENS.cardBg : "rgba(255,255,255,0.06)",
        backdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(16px) saturate(150%)",
        WebkitBackdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(16px) saturate(150%)",
        border: ft.glassic ? `1px solid ${accent}55` : `1px solid ${accent}44`,
        boxShadow: ft.glassic ? GLASSIC_TOKENS.cardShadow : "none",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Avatar name={name} photoURL={photoURL} size={54} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: Math.round(14 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{name}</div>
          {side === "friend" && (
            <motion.button whileHover={{ y: -1 }} whileTap={{ scale: 0.95 }} onClick={onOpenMemory}
              style={{ marginTop: 4, border: "none", background: C.blue, color: C.dark, borderRadius: 999, padding: "3px 10px", fontSize: 9.5, fontWeight: 800, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 4 }}>
              <BookOpen size={10} /> Memory
            </motion.button>
          )}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <div style={{ flex: 1, background: "rgba(74,124,89,0.18)", borderRadius: 10, padding: "7px 10px" }}>
          <div style={{ fontSize: Math.round(8.5 * ft.scale), fontWeight: ft.bold ? 800 : 700, color: ft.text, opacity: 0.6 }}>Total Earn</div>
          <div style={{ fontSize: Math.round(13 * ft.scale), fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.earnColor : "#7bd389" }}>₹{Math.round(totalEarn)}</div>
        </div>
        <div style={{ flex: 1, background: "rgba(230,57,70,0.18)", borderRadius: 10, padding: "7px 10px" }}>
          <div style={{ fontSize: Math.round(8.5 * ft.scale), fontWeight: ft.bold ? 800 : 700, color: ft.text, opacity: 0.6 }}>Total Spend</div>
          <div style={{ fontSize: Math.round(13 * ft.scale), fontWeight: 900, color: ft.glassic ? GLASSIC_TOKENS.spendColor : "#f4a261" }}>₹{Math.round(totalSpend)}</div>
        </div>
      </div>

      {loading ? (
        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", padding: "16px 0", textAlign: "center" }}>Loading {name}'s data...</div>
      ) : (
        <>
          <div style={{ display: "flex", justifyContent: "space-around", padding: "4px 0" }}>
            <MiniRing pct={stats?.dailyPct} color={C.accent} label="Daily" />
            <MiniRing pct={stats?.extryPct} color={C.blue} label="Extry" />
            <MiniRing pct={stats?.overallPct} color="#7209b7" label="Overall" />
            <MiniRing pct={Math.min(100, ((stats?.streak || 0) / 30) * 100)} color="#e63946" label={`🔥 ${stats?.streak || 0}`} />
            <MiniRing pct={stats?.lifeScore} color="#7bd389" label="Score" />
          </div>

          <ViewTabs value={view} onChange={setView} accent={accent} />

          <div style={{ flex: 1, minHeight: 0, overflowY: "auto" }} className="btl-scroll">
            <AnimatePresence mode="wait" initial={false}>
              {view === "goals" ? (
                <motion.div key="goals" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}
                  style={{ display: "flex", flexDirection: "row", alignItems: "stretch", gap: 0, height: "100%", minHeight: 0 }}>
                  <GoalMiniList title="Daily Goals" items={dailyGoals} accent={accent} row />
                  <GoalMiniList title="Extry Goals" items={extryGoals} accent={accent} row />
                  <TimeTableMiniList items={timeTable} accent={accent} row />
                </motion.div>
              ) : view === "rules" ? (
                <motion.div key="rules" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}
                  style={{ display: "flex" }}>
                  <TextMiniList items={lifeRules} icon={ShieldCheck} emptyLabel="No life rules set yet." />
                </motion.div>
              ) : (
                <motion.div key="big" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.18 }}
                  style={{ display: "flex" }}>
                  <TextMiniList items={bigGoals} icon={Target} emptyLabel="No big goals set yet." />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </>
      )}
    </motion.div>
  );
}

function FriendVSView({ user, myState, myStats, friend, friendState, onBack, onOpenChat, onOpenMemory, onOpenThemeSettings }) {
  const ft = useFriendTheme();
  const friendStats = useMemo(() => computeStatsFromState(friendState), [friendState]);

  return (
    <motion.div
      key="vs"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}
      style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", padding: "18px 22px 14px", overflow: "hidden" }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexShrink: 0 }}>
        <motion.button whileHover={{ x: -3 }} whileTap={{ scale: 0.92 }} onClick={onBack}
          style={{ background: ft.glassic ? GLASSIC_TOKENS.chipBg : "rgba(255,255,255,0.12)", border: "none", borderRadius: 999, padding: "7px 14px", color: ft.glassic ? GLASSIC_TOKENS.text : "#fff", display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 11, fontWeight: 800 }}>
          <ArrowLeft size={14} /> Back
        </motion.button>
        {/* Friend Celebration theme shortcut — same jump-to Setting ->
            Theme -> Friend Celebration as the hub header's gear icon. */}
        <motion.button whileHover={{ scale: 1.1, rotate: 25 }} whileTap={{ scale: 0.9 }} onClick={onOpenThemeSettings} title="Friend Celebration theme"
          style={{ background: ft.glassic ? GLASSIC_TOKENS.chipBg : "rgba(255,255,255,0.12)", border: "none", borderRadius: "50%", width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", color: ft.glassic ? GLASSIC_TOKENS.text : "#fff", cursor: "pointer", flexShrink: 0 }}>
          <Settings size={14} />
        </motion.button>
        <div style={{ flex: 1, textAlign: "center", fontSize: Math.round(14 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text, display: "flex", alignItems: "center", justifyContent: "center", gap: 8, minWidth: 0 }}>
          <Zap size={14} color={C.accent} />
          <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {(user?.displayName || "You").split(" ")[0]} <span style={{ color: "#e63946", fontStyle: "italic" }}>VS</span> {(friend?.name || "Friend").split(" ")[0]}
          </span>
        </div>
        <motion.button whileHover={{ y: -2, scale: 1.06 }} whileTap={{ scale: 0.9 }} onClick={onOpenChat}
          style={{ background: C.accent, border: "none", borderRadius: 999, padding: "7px 14px", color: "#fff", display: "flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 11, fontWeight: 800 }}>
          <MessageCircle size={14} /> Chat
        </motion.button>
      </div>

      {/* Step 8 — mobile responsive pass: desktop keeps the original hardcoded
          "1fr 1fr" side-by-side split (untouched, per the hard constraint).
          On mobile (<=768px) the "btl-vs-grid" class below overrides it to a
          single column so You/Friend stack vertically instead of squeezing
          two columns into a narrow screen — user's explicit call. */}
      <div style={{ flex: 1, minHeight: 0, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 18, overflowY: "auto" }} className="btl-scroll btl-vs-grid">
        <PlayerColumn
          side="me"
          name={user?.displayName || user?.email || "You"}
          photoURL={user?.photoURL}
          totalEarn={myState?.totalEarnLife || 0}
          totalSpend={myState?.totalSpendLife || 0}
          stats={myStats}
          dailyGoals={myState?.dailyGoals || []}
          extryGoals={myState?.extryGoals || []}
          timeTable={myState?.timeTable || []}
          lifeRules={myState?.lifeRules || []}
          bigGoals={myState?.bigGoals || []}
        />
        <PlayerColumn
          side="friend"
          name={friend?.name || "Friend"}
          photoURL={friend?.photoURL}
          totalEarn={friendState?.totalEarnLife || 0}
          totalSpend={friendState?.totalSpendLife || 0}
          stats={friendStats}
          dailyGoals={friendState?.dailyGoals || []}
          extryGoals={friendState?.extryGoals || []}
          timeTable={friendState?.timeTable || []}
          lifeRules={friendState?.lifeRules || []}
          bigGoals={friendState?.bigGoals || []}
          loading={!friendState}
          onOpenMemory={onOpenMemory}
        />
      </div>
    </motion.div>
  );
}

/* ---------------- glass chat popup ---------------- */

function FriendChatModal({ user, friend, fsId, onClose }) {
  const ft = useFriendTheme();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  // this update: how many px the on-screen keyboard is currently covering, so
  // the input bar can float just above it (WhatsApp-style) instead of being
  // hidden underneath it. Stays 0 on desktop — no on-screen keyboard there.
  const [kbOffset, setKbOffset] = useState(0);
  const endRef = useRef(null);

  useEffect(() => {
    if (!fsId) return;
    const unsub = listenChatMessages(fsId, setMessages);
    return unsub;
  }, [fsId]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages.length]);

  // this update: track the mobile on-screen keyboard via visualViewport — when
  // it opens, the viewport shrinks by roughly the keyboard's height, so we read
  // that gap and shift the input bar up by the same amount every time it changes.
  useEffect(() => {
    if (typeof window === "undefined" || !window.visualViewport) return;
    const vv = window.visualViewport;
    const handleResize = () => {
      const offset = Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
      setKbOffset(offset);
    };
    vv.addEventListener("resize", handleResize);
    vv.addEventListener("scroll", handleResize);
    handleResize();
    return () => {
      vv.removeEventListener("resize", handleResize);
      vv.removeEventListener("scroll", handleResize);
    };
  }, []);

  const send = async () => {
    if (!text.trim() || sending) return;
    setSending(true);
    try {
      await sendChatMessage(fsId, user.uid, user.displayName || user.email, text);
      setText("");
    } finally {
      setSending(false);
    }
  };

  return (
    <motion.div
      className="btl-chat-overlay"
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }}
      style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.55)", zIndex: 20, display: "flex", alignItems: "center", justifyContent: "center", backdropFilter: "blur(4px)", WebkitBackdropFilter: "blur(4px)" }}
      onClick={onClose}
    >
      <motion.div
        className="btl-chat-card"
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, scale: 0.9, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.92, y: 14 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
        style={{
          width: "min(420px, 92vw)", height: "min(560px, 82vh)",
          background: ft.glassic ? "linear-gradient(160deg, rgba(255,255,255,0.82), rgba(238,240,243,0.75))" : "rgba(37,36,34,0.78)",
          backdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(24px) saturate(180%)",
          WebkitBackdropFilter: ft.glassic ? GLASSIC_TOKENS.blur : "blur(24px) saturate(180%)",
          border: ft.glassic ? "1px solid rgba(255,255,255,0.85)" : "1px solid rgba(255,255,255,0.18)",
          borderRadius: 22,
          boxShadow: ft.glassic ? "0 30px 70px rgba(163,177,198,0.45), 0 2px 0 rgba(255,255,255,0.9) inset" : "0 30px 80px rgba(0,0,0,0.5)",
          display: "flex", flexDirection: "column", overflow: "hidden",
        }}
      >
        <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 10, borderBottom: ft.glassic ? "1px solid rgba(0,0,0,0.08)" : "1px solid rgba(255,255,255,0.12)", flexShrink: 0 }}>
          <Avatar name={friend?.name} photoURL={friend?.photoURL} size={34} />
          <div style={{ fontSize: Math.round(13 * ft.scale), fontWeight: ft.bold ? 900 : 900, color: ft.text, flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{friend?.name}</div>
          <motion.button whileHover={{ rotate: 90, scale: 1.1 }} whileTap={{ scale: 0.9 }} onClick={onClose}
            style={{ background: ft.glassic ? GLASSIC_TOKENS.chipBg : "rgba(255,255,255,0.1)", border: "none", borderRadius: "50%", width: 28, height: 28, display: "flex", alignItems: "center", justifyContent: "center", color: ft.glassic ? GLASSIC_TOKENS.text : "#fff", cursor: "pointer" }}>
            <X size={14} />
          </motion.button>
        </div>

        <div className="btl-scroll" style={{ flex: 1, minHeight: 0, overflowY: "auto", padding: "14px 14px 4px", display: "flex", flexDirection: "column", gap: 8 }}>
          {messages.length === 0 && <div style={{ margin: "auto", fontSize: 11, color: ft.glassic ? GLASSIC_TOKENS.faint : "rgba(255,255,255,0.35)" }}>Say hi to {friend?.name}! 👋</div>}
          {messages.map((m) => {
            const mine = m.fromUid === user.uid;
            return (
              <motion.div key={m.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                style={{
                  alignSelf: mine ? "flex-end" : "flex-start", maxWidth: "78%",
                  background: mine ? "linear-gradient(135deg,#fca311,#e07a5f)" : (ft.glassic ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.1)"),
                  color: mine ? "#fff" : (ft.glassic ? GLASSIC_TOKENS.text : "#fff"),
                  borderRadius: mine ? "14px 14px 4px 14px" : "14px 14px 14px 4px",
                  padding: "8px 12px", fontSize: 12, wordBreak: "break-word",
                }}>
                {m.text}
              </motion.div>
            );
          })}
          <div ref={endRef} />
        </div>

        <div
          className="btl-chat-inputbar"
          style={{
            display: "flex", gap: 8, padding: 12, flexShrink: 0,
            borderTop: ft.glassic ? "1px solid rgba(0,0,0,0.08)" : "1px solid rgba(255,255,255,0.12)",
            transform: kbOffset ? `translateY(-${kbOffset}px)` : undefined,
          }}
        >
          <input
            value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Type a message..."
            style={{
              flex: 1, fontSize: 12, padding: "10px 12px", borderRadius: 999, outline: "none",
              border: ft.glassic ? GLASSIC_TOKENS.inputBorder : "1px solid rgba(255,255,255,0.18)",
              background: ft.glassic ? GLASSIC_TOKENS.inputBg : "rgba(255,255,255,0.08)",
              color: ft.glassic ? GLASSIC_TOKENS.text : "#fff",
            }}
          />
          <motion.button whileHover={{ scale: 1.08 }} whileTap={{ scale: 0.9 }} onClick={send} disabled={sending}
            style={{ width: 38, height: 38, borderRadius: "50%", border: "none", background: C.accent, color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", flexShrink: 0, opacity: sending ? 0.7 : 1 }}>
            <Send size={15} />
          </motion.button>
        </div>
      </motion.div>

      {/* this update: full-screen chat, mobile only — desktop keeps the
          existing centered glass card untouched (no className match above 768px). */}
      <style jsx>{`
        @media (max-width: 768px) {
          .btl-chat-card {
            width: 100vw !important;
            height: 100vh !important;
            height: 100dvh !important;
            max-width: none !important;
            max-height: none !important;
            border-radius: 0 !important;
          }
        }
      `}</style>
    </motion.div>
  );
}

/* ---------------- root ---------------- */

export default function FriendCelebration({ user, myState, myStats, onClose, theme, onOpenThemeSettings }) {
  const [phase, setPhase] = useState("intro"); // intro | hub | vsIntro | vs
  const phaseRef = useRef(phase);
  useEffect(() => { phaseRef.current = phase; }, [phase]);

  const [activeFriend, setActiveFriend] = useState(null);
  const [friendState, setFriendState] = useState(null);
  const [friendships, setFriendships] = useState([]);
  const [incoming, setIncoming] = useState([]);
  const [outgoing, setOutgoing] = useState([]);
  const [chatOpen, setChatOpen] = useState(false);
  const [memoryOpen, setMemoryOpen] = useState(false);
  const seenIds = useRef(null);

  useEffect(() => {
    if (!user) return;
    const u1 = listenFriendships(user.uid, (list) => {
      // If a fresh friendship shows up while we're sitting on the hub
      // (i.e. the other person just accepted our invite), jump straight
      // into their VS screen with its own intro animation.
      if (seenIds.current) {
        const fresh = list.find((f) => !seenIds.current.has(f.id));
        if (fresh && phaseRef.current === "hub") {
          setActiveFriend(fresh);
          setPhase("vsIntro");
        }
      }
      seenIds.current = new Set(list.map((f) => f.id));
      setFriendships(list);
    });
    const u2 = listenIncomingRequests(user.uid, setIncoming);
    const u3 = listenOutgoingRequests(user.uid, setOutgoing);
    return () => { u1(); u2(); u3(); };
  }, [user]);

  useEffect(() => {
    if (phase !== "intro") return;
    const t = setTimeout(() => setPhase("hub"), 1500);
    return () => clearTimeout(t);
  }, [phase]);

  useEffect(() => {
    if (!activeFriend?.otherUid) { setFriendState(null); return; }
    const unsub = listenFriendState(activeFriend.otherUid, setFriendState);
    return unsub;
  }, [activeFriend?.otherUid]);

  const selectFriend = (f) => { setActiveFriend(f); setPhase("vsIntro"); };
  const backToHub = () => { setPhase("hub"); setChatOpen(false); setMemoryOpen(false); };

  const fsId = user && activeFriend ? friendshipId(user.uid, activeFriend.otherUid) : null;

  const ft = normalizeScopeTheme(theme);
  const glassic = !!ft.liquidGlassic;
  const friendTheme = {
    bg: glassic ? GLASSIC_TOKENS.pageBg : (ft.bg || FRIEND_THEME_DEFAULT.bg),
    text: glassic ? GLASSIC_TOKENS.text : (ft.text || FRIEND_THEME_DEFAULT.text),
    fontFamily: ft.font ? fontStackFor(ft.font) : undefined,
    bold: ft.bold,
    scale: ft.scale || 1,
    glassic,
    tokens: glassic ? GLASSIC_TOKENS : null,
  };

  return (
    <FriendThemeCtx.Provider value={friendTheme}>
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}
      style={{ position: "absolute", inset: 0, zIndex: 95, background: friendTheme.bg, overflow: "hidden", fontFamily: friendTheme.fontFamily }}
    >
      <style>{`
        @keyframes btlFriendSpin { to { transform: rotate(360deg); } }
        .btl-spin { animation: btlFriendSpin 0.9s linear infinite; }

        /* ---------------- Step 8 — VS screen mobile stack ----------------
           Desktop: .btl-vs-grid keeps its inline "1fr 1fr" (untouched).
           Mobile (<=768px, same breakpoint as the rest of the radial redesign):
           single column, You's card first then Friend's card below it, with a
           bit less gap since vertical space is scarcer than horizontal on a
           360-430px phone. Nothing inside PlayerColumn itself changes — it
           already sizes off its own container width. */
        @media (max-width: 768px) {
          .btl-vs-grid { grid-template-columns: 1fr !important; gap: 12px !important; }
        }
      `}</style>

      <AnimatePresence mode="wait">
        {phase === "intro" && (
          <VSIntro key="intro" leftPhoto={user?.photoURL} leftName={user?.displayName || "You"} rightPhoto="" rightName="Friends" onDone={() => setPhase("hub")} />
        )}
        {phase === "hub" && (
          <FriendHubView key="hub" user={user} friendships={friendships} incoming={incoming} outgoing={outgoing} onSelectFriend={selectFriend} onClose={onClose} onOpenThemeSettings={onOpenThemeSettings} />
        )}
        {phase === "vsIntro" && activeFriend && (
          <VSIntro key="vsintro" leftPhoto={user?.photoURL} leftName={user?.displayName || "You"} rightPhoto={activeFriend.photoURL} rightName={activeFriend.name} onDone={() => setPhase("vs")} />
        )}
        {phase === "vs" && activeFriend && (
          <FriendVSView
            user={user} myState={myState} myStats={myStats} friend={activeFriend} friendState={friendState}
            onBack={backToHub} onOpenChat={() => setChatOpen(true)} onOpenMemory={() => setMemoryOpen(true)}
            onOpenThemeSettings={onOpenThemeSettings}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {chatOpen && activeFriend && fsId && (
          <FriendChatModal user={user} friend={activeFriend} fsId={fsId} onClose={() => setChatOpen(false)} />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {memoryOpen && activeFriend && friendState && (
          <MemoriesModal state={friendState} onAddMemory={() => {}} onClose={() => setMemoryOpen(false)} readOnly />
        )}
      </AnimatePresence>
    </motion.div>
    </FriendThemeCtx.Provider>
  );
}
