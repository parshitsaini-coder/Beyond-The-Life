# BTL — Real Google OAuth (Firebase) + Vercel hosting

## 🎉 Ribbon celebration when Daily Goals + Time Table both hit 100% (this update)
Per your screenshot markup (circles around Daily Goals and the Time Table
widget, with arrows sweeping up from the left and right): finishing every
item in **both** the Daily Goals list and the Time Table now triggers a
dedicated celebration — separate from the existing Daily+Extry streak
confetti, since Time Table isn't part of that pair.

- New `RibbonCelebration` component — two ribbon streams launch from the
  bottom-left and bottom-right corners of the dashboard and sweep upward,
  drifting inward toward the top-center as they rise and fade (left ribbons
  drift right, right ribbons drift left, so the two streams lean toward each
  other rather than just going straight up).
- New `checkDailyTimeTableCelebration()` — checked on every Daily Goals
  toggle and every Time Table toggle; fires once the moment both lists are
  fully checked off, and won't re-fire again the same day (tracked via
  `state.lastRibbonCelebrated`, same pattern as the existing streak's
  `lastCompletedDate`) even if you keep re-toggling items after both are
  already done.
- Pure CSS keyframes (per-ribbon drift/rotation passed in as CSS custom
  properties), same lightweight approach as the existing Confetti piece —
  no new dependencies.

## 📐 Fix: Daily Goals / Extry Goals / Time Table stretching with dead space (this update)
Per your screenshot markup — on the friend's (lighter-content) side
especially, each of the three list cards under the "Goals" tab was
force-stretching (`flex: 1`) to equally split whatever vertical room
was left in the column, so a short list like "Extry Goals — No goals
yet." ballooned into a huge mostly-empty box instead of just sitting
compact. That's why dev's side (more items) looked fine while
lakshit's side had big gaps between each block.

- `GoalMiniList`, `TimeTableMiniList`, and `TextMiniList` (Life Rules /
  Big Goals) now size to their own content (`flexShrink: 0`, a
  `maxHeight` cap with its own scroll only if a single list genuinely
  runs long) instead of stretching to fill the column.
- The three now simply stack vertically, tight against each other —
  exactly where you circled — and the column around them scrolls as
  one unit if the total content is taller than the card.

## ⚔️ Friend Celebration VS screen — Time Table, animated ticks, Life Rules/Big Goals tabs (earlier update)
Per your screenshot markup on the "dev VS lakshit" split-screen: three
changes to `components/FriendCelebration.jsx`'s `PlayerColumn`.

- **Time Table now shows on both sides.** New `TimeTableMiniList` —
  same card language as the Daily/Extry `GoalMiniList`s already there,
  scheduled time shown first (`formatTime12`, now exported from
  `BTLDashboard.jsx` so this file can reuse the exact same 12h format
  as the main dashboard's own Time Table widget).
- **Completed items get a real "landed" moment.** New shared
  `DoneCheck` — the plain `Circle -> CheckCircle2` icon swap is now a
  spring pop-in with a soft green burst ring expanding and fading
  behind the check, plus the row itself washes to a light green tint.
  Used by both `GoalMiniList` and `TimeTableMiniList`, so this applies
  to Daily Goals, Extry Goals, and Time Table alike, on both sides.
- **Two new tabs — Life Rules and Big Goals — where you circled above
  the lists.** New `ViewTabs`, a small sliding-pill segmented control
  ("Goals" / "Life Rules" / "Big Goals") sitting right under each
  side's ring stats. "Goals" (the default) is the Daily + Extry + Time
  Table set above; the other two flip that side over to a new
  `TextMiniList` reading back that person's own `lifeRules` /
  `bigGoals` arrays (same plain-string data the main dashboard's
  `TextList` widget shows, read-only here). Each `PlayerColumn` keeps
  its own tab state, so you can sit on your own Goals tab while
  checking your friend's Life Rules, or vice versa.
- Pure `framer-motion` + CSS, same as the rest of the file — no new
  dependencies.

## 🔥 Active Streak goal names in a top-right corner ticker (earlier update)
Per your screenshot markup (the arrow pointing at the empty space above
the header stat row, top-right of the whole dashboard): the existing
"Active Streaks" badge below only ever showed a *count* — you could see
"3" but not which 3 goals. This adds the missing piece right where you
marked it.

- `getActiveStreakGoals()` — same day-walking-backward logic
  `countActiveStreakGoals()` already uses, except it keeps each goal's
  id/text/icon/streak instead of collapsing to a number, combined
  across Daily + Extry Goals and sorted longest streak first.
- `ActiveStreakGoalsCorner` — new, pinned to `.btl-app-root`'s own
  top-right corner (`position: absolute`, above the entire header row,
  not just tucked into it), rendering one animated pill per
  currently-streaking goal: flame + optional goal emoji + name +
  live streak count. Renders nothing when no streaks are active, so it
  never clutters the corner on a quiet day.
- Each pill gets the same "genuine fire" treatment as the
  `ActiveStreaksBadge` flame, scaled down: a breathing ember-glow behind
  it, 3 embers drifting up and fading, the flame glyph itself flickering
  (scale/rotate jitter), a slow ambient bob so the strip never sits
  dead-still, a spring pop-in/out via `AnimatePresence` whenever a goal
  starts or drops its streak, and a spring pop on the streak number
  itself when it ticks up.
- Pure `framer-motion` + CSS, same as every other animation in this
  file — no new dependencies pulled in for this.

## 🔥 New "Active Streaks" header badge (earlier update)
Added a brand-new indicator to the header stat cluster (mobile stats row
+ desktop header, right where the existing Day Streak / Daily Goal /
Extry Goal / Goal / Time Table badges live) — separate from the
existing "Day Streak" badge (which tracks the overall "everything got
done N days running" streak). This new one answers a different
question: **how many individual goals right now have "Start Streak"
switched on and are actually mid-streak** (running ≥1 day)?

- `countActiveStreakGoals()` — a plain helper (not a hook, since it's
  read after `BTLDashboardInner`'s early `if (!state) return`, same as
  `dailyPct`/`extryPct` next to it) that combines the exact
  day-walking-backward logic GoalChecklist's own per-goal streak counts
  already use, across both Daily Goals and Extry Goals.
- `ActiveStreaksBadge` — new component next to `DayStreakBadge`. At 0
  it's a calm, static, desaturated flame (so it never fakes a fire that
  isn't there). The moment the count is > 0 it comes alive: a breathing
  radial ember-glow behind it, 5 embers drifting upward and fading on
  staggered loops, the flame glyph itself flickering (scale + rotate +
  skew jitter, not just a static icon), and a count pill that
  spring-pops whenever the number changes.
- Pure framer-motion + CSS, same as every other animation in this file
  — no new dependencies, no WebGL.

## 🏋️ Fitness shortcut added to the mobile top quicknav row (earlier update)
The mobile top bar's round icon row (Time Table / Analytics / Friend
Celebration / Share Journal) was missing a way to jump straight to the
Fitness tab — you had to go through the desktop-only QuickNavFab instead.

- Added a 5th `Dumbbell` icon button to `.btl-mobile-quicknav`, same
  36px round dark pill style as the other four, calling `setTab("fitness")`
  — the exact same tab the desktop QuickNavFab's "Fitness" shortcut
  already opens, so no new screen/route was built, just a faster way in.

## 🎨 Proper custom UI for the goal Category/Priority dropdowns (earlier update)
The "Add item" options row on a goal checklist card (Category + Priority)
was still using raw HTML `<select>` elements — plain OS-chrome dropdowns
(the flat grey "Other ⌄" / "Medium priority ⌄" boxes) that didn't match
the rest of the app's glassy, animated popover style, unlike Time Table's
category picker which already got the custom-popover treatment earlier.

- Both dropdowns on the goal add-item row now reuse the same
  `CategoryDropdown` + `CategoryPickerPanel` component Time Table already
  uses — a pill button with an emoji + chevron that opens a glass
  blur-backdrop popover (spring-animated, viewport-aware so it flips
  above the button near the bottom of the screen, closes on outside
  click/scroll/resize), with a colored highlight + checkmark on the
  selected row. This is the same generic component, just pointed at a
  different list — no new popover code needed.
- `CATEGORIES` (Health/Money/Career/Relations/Personal/Other) got emoji
  added (💪💰💼❤️🧑🔖) so they render the same as Time Table's categories.
- `PRIORITIES` (High/Medium/Low) got a small traffic-light dot emoji each
  (🔴🟠🟢) instead of no icon, so priority is readable at a glance in the
  closed pill, not just from the text.
- Both dropdowns are already wrapped in the `PopoverErrorBoundary` added
  above (they render through the same `CategoryDropdown` component), so
  this doesn't reopen the "one crash blanks the whole dashboard" issue.

## 🛡️ Popover-scoped error boundary for Category/Time/Emoji pickers (earlier update)
Reported crash: tapping the Time Table add-row's ⏰ button threw
`ReferenceError: PANEL_W is not defined`, which crashed the **entire**
dashboard behind the "Something went wrong — Reload dashboard" screen —
because the whole app only has one top-level `BTLErrorBoundary`, so any
error anywhere in the tree takes the whole thing down.

Checked `PANEL_W` in both `CategoryPickerPanel` and `TimePickerPanel` in
`components/BTLDashboard.jsx` — each already declares its own
`const PANEL_W` before use, and a full `npm run build` compiles clean
with no such reference error, so that specific bug isn't present in this
codebase (likely an old cached deployment/bundle). Added a safety net
regardless, since a popover is the wrong place for any future bug to be
able to blank out the whole app:

- New `PopoverErrorBoundary` — a small class component (same
  `getDerivedStateFromError`/`componentDidCatch` shape as the existing
  `BTLErrorBoundary`), placed right above `CategoryPickerPanel`.
- Wraps all four render sites of the three portal popovers —
  `CategoryPickerPanel` (in `CategoryDropdown`), `TimePickerPanel` (in
  `TimePicker`), and both `EmojiPickerPortal` call sites (goal icon
  picker, add-form icon picker).
- On error it renders nothing and calls the popover's own `onClose()`
  — so a bug in a 150px popover just closes that popover instead of
  taking down the whole dashboard. Since each popover only mounts while
  its `anchor`/`picker` state is truthy, a fresh instance mounts clean
  next time it's opened — no extra reset wiring needed.
- Nothing about `BTLErrorBoundary` itself changed — it's still the
  final fallback for anything outside these four spots.

## 🐛 Fix: Time picker "not opening" + Category/emoji popup closing itself on scroll (earlier update)
Both bugs you flagged (from your screenshots — the mobile Time Table
add-row's ⏰ and 🏷 buttons) turned out to share one root cause in
`components/BTLDashboard.jsx`.

Three popovers — `CategoryPickerPanel`, `TimePickerPanel`, and
`EmojiPickerPortal` (the 😀 button in the goal add-form) — each close
themselves on outside-click, on window resize, **and on any `scroll`
event**, so a stale popover doesn't stay glued to the wrong spot if the
page behind it moves. That scroll listener was attached with
`window.addEventListener("scroll", handleDismiss, true)` and closed the
popover on **every** scroll event it saw — including scroll events fired
by the popover's *own* content:

- **Category/emoji popup "won't scroll, jumps back"**: scrolling the
  category list or emoji grid fires a scroll event on that inner
  `overflowY: auto` container. The old listener caught that too and
  called `onClose()` immediately — so the very first scroll tick closed
  the popup and dropped you back on the page behind it, looking exactly
  like "scroll nahi hota, sidha background chala jata hai."
- **Time picker "won't open"**: the hour/minute wheel columns
  (`TimeWheelColumn`) auto-scroll the current value into view the instant
  they mount (`scrollIntoView`) — which fires a scroll event too. The
  panel's own listener caught its own opening scroll and closed itself in
  the same frame, so tapping the time button looked like nothing
  happened at all.

**Fix**: the scroll-dismiss handler in all three now ignores scroll
events whose target is inside the popover itself, and only closes on
scrolls that happen outside it (the actual "page moved, reposition/close
me" case it was meant for):
```js
const handleDismiss = (e) => {
  if (ref.current && ref.current.contains(e.target)) return; // internal scroll — leave it open
  onClose();
};
```
Nothing else about these three components changed — same positioning,
same outside-click/resize dismissal, same portal-to-`document.body`
rendering.

## 🔄 Pro swap animation on the mobile Daily Goal / Time Table / Focus Timer card (this update)
Per your screenshot markup: tapping the orange ⇄ button on the mobile quick
card (`btl-mobile-quickgoals`, `components/BTLDashboard.jsx`) no longer
instant-swaps the content — it's now a proper animated transition, built
entirely with `framer-motion` (already a dependency):

- **3D card-flip** — the outgoing widget (Daily Goals / Time Table / Focus
  Timer) rotates away on the Y-axis and fades/scales down while the
  incoming one rotates in from the opposite face, like a physical card
  being flipped — not a hard content swap. Spring physics
  (`stiffness: 260, damping: 26`), so it settles with a touch of bounce
  rather than a linear ease.
- **Spinning swap button** — the ⇄ button itself does a full 180° spring
  rotation every tap (cumulative, so two taps = 360°, etc.), plus a quick
  press-down `scale: 0.8` on tap and a slight hover lift.
- **Expanding ring burst** — every tap also fires a thin accent-colored
  ring from the button's center that expands and fades out, like a
  ripple/sonar ping, reinforcing that the swap was registered.
- **Animated corner label** — a small pill (icon + name — Daily Goals /
  Time Table / Focus Timer) fades and slides in at the top-left each time
  the view changes, so it's immediately clear what you just swapped into,
  independent of the flip animation.

All four are pure `framer-motion` (`motion.div`/`motion.button`,
`AnimatePresence`) — no new dependency, and none of `mobileQuickView`'s
underlying state/cycle logic changed (still Daily Goals → Time Table →
Focus Timer → back to Daily Goals). Desktop grid and the radial dial's
widget panels are untouched.

## 🔥 "Start Streak" per-goal option in Daily/Extra Goals (this update)
Per your screenshots: Daily Goals (and Extra Goals, same widget component)
now has an opt-in per-goal streak, right in the widget itself — not just
in Analytics.

- **Adding a new goal**: tap the 🏷 options button next to "Add item…"
  (same button that already opens Category / Priority / Recurring) —
  the popup that opens below now also has a **"🔥 Start Streak"**
  checkbox. Check it and the goal is created with streak tracking on.
- **An existing goal**: tap its row to expand (the ⌄ chevron), and the
  same "🔥 Streak" checkbox is there next to its category tag — toggle it
  on/off any time, no need to delete and re-add the goal.
- **The flame badge**: any streak-enabled goal shows a small pulsing
  flame + its current day-count right next to its name, live.
- **The reset**: this needed no separate "reset" code — the streak count
  is computed fresh from `dailyLogs[date].completedGoals[daily/extry]`
  (the same per-day snapshot of exactly which goal ids were done, already
  recorded on every toggle) walked backward from today. The moment a
  full day goes by without that goal being ticked, the next recorded day
  simply won't have it in the snapshot, so the flame's count naturally
  drops back to 0 on its own — same convention the Analytics → Deep
  Analytics "Per-goal streaks" / "Best-ever streak per goal" widgets
  already use, just surfaced live on the widget now too.

## 📤 Time Table score added next to Daily Goals ring on the Share card (earlier update)
Per your screenshot markup: the **Share Your Journey** card's big score
ring now shows Time Table alongside Daily Goals, not just Daily Goals
alone. Both in `generateShareCard` (`components/BTLDashboard.jsx`):

- **Daily Goals** stays the primary ring, same size and position feel as
  before, on the left.
- **Time Table** is a new, smaller secondary ring on the right, same
  "progress ring + %  + done/total" language, colored with the same
  purple (`#8a6fd6`) the Time Table ring already uses in the dashboard
  header (RingStat) and Analytics — so it visually matches everywhere
  else Time Table progress shows up.
- Reads straight off `state.timeTable` (done vs total), the same field
  the header's Time Table ring and completion % already use — nothing
  new to store.

## 🕛 Fix: daily reset now happens at local midnight, not 5:30 AM (earlier update)
You flagged that Daily Goals / Extra Goals / Time Table checkboxes should
reset when "the day ends" — turns out they were resetting at **5:30 AM
IST**, not midnight. Root cause found and fixed in `components/BTLDashboard.jsx`:

- The app's shared `todayISO()` helper — used everywhere something needs
  today's date as a key (goal/Time Table reset, streaks, mood log, money
  history, completionHistory, dailyLogs, etc.) — was built from
  `new Date().toISOString().slice(0, 10)`, which is the **UTC** calendar
  date, not your device's local one. Since IST is UTC+5:30, the UTC date
  only rolls over at 5:30 AM local time — so that's when every reset tied
  to it actually fired, a full 5.5 hours late.
- `todayISO()` now builds the date string from the local `Date` getters
  (`getFullYear`/`getMonth`/`getDate`) instead, so "today" always means
  true local midnight-to-midnight — same convention the Calendar/Memories
  widgets' own `localDateToISO` already used.
- Went further and swept every other spot in the file computing a
  "N days ago" date key for charts/trends/filters (Focus Timer & Fitness
  breakdowns, Analytics weekday/momentum/money-velocity, mood trend, Past
  Data date range, etc.) — all 16 of them were using the same UTC-based
  `.toISOString().slice(0, 10)` pattern. Pulled them all into one shared
  `dateISO(d)` helper (also local-date-based) so every date key in the app
  now agrees with `todayISO()` — otherwise those charts would've stayed
  silently misaligned by a day specifically during the 12:00–5:29 AM IST
  window, even after the main reset was fixed.

Nothing about *what* gets stored changed — only when "today" flips over.
Past dates already saved (streak history, mood log, money history, etc.)
are untouched; only new day-keys going forward use the corrected local
date.

## 🏆 "Best-ever streak per goal" widget added (earlier update)
One more Deep Analytics widget, right after "Goal consistency — last 30
days": per goal, its **longest-ever run** of consecutive calendar days
completed — not just the streak still active today. Sorted longest-first,
with a small "● NOW" tag on any goal whose current streak has actually
reached (i.e. is tying or re-setting) its own all-time best.

Computed the same way the existing top-level "Streak record" widget
checks for calendar-day continuity (a skipped or unrecorded day breaks
the run), just walked per-goal using the same
`dailyLogs[date].completedGoals` snapshots the streak/consistency widgets
below it already use — still nothing new stored.

## 🎯 Per-goal streak & consistency widgets in Deep Analytics (earlier update)
Two new widgets added to Analytics & Insights → **🔬 Deep Analytics** (after
"Weekly momentum"), going deeper than the existing whole-list stats —
per **individual** Daily/Extra Goal this time, not just the combined %:

- **Per-goal streaks** — for every goal that's currently on a streak, shows
  how many *consecutive* days in a row it's been ticked off, sorted longest
  first (flame icon, colored by list: Daily Goals accent vs Extra Goals
  blue).
- **Goal consistency — last 30 days** — every goal that has at least one
  recorded day, as a % of the last 30 *recorded* days (days the app was
  actually used) it was completed on — same bar-row style as "Category
  performance" above it.

Both are computed from data that already existed and needed no new
schema: `dailyLogs[date].completedGoals.{daily,extry}` already snapshots
exactly which goal **ids** were done each day (this was already recorded
on every toggle, originally for the Memories modal) — matching a goal's
current id against that day-by-day snapshot going backward gives its true
streak and consistency, per goal, with nothing fabricated and nothing new
to store. A goal only counts days from *after* it was created (no
snapshot before that), so a brand-new goal won't be unfairly scored
against days it didn't exist.

## ⏱️ Per-category "today" widgets in Analytics → Focus Time (earlier update)
Per your screenshot markup: the **Focus Time — last 30 days** section
(Analytics & Insights tab) now shows a small widget card for **every
Focus Timer category** — Screen time / Social media / Deep work / Study by
default, plus any custom category you've added from the Focus Timer
widget's own "+" popup — right below the existing Focused today / 7-day
avg / Top category row.

Each card shows: the category's own colored dot (same color used
everywhere else — the widget, the 30d breakdown donut below), the
category name, and **today's tracked time** for just that category
(`focusSecondsToday` — same helper the Focus Timer widget itself uses).
If a category is the one currently running, its card gets a highlighted
border/background in its color and a small "● LIVE" tag, and its time
keeps ticking up live, same as the widget.

## 📊 Analytics & Layout icons added to desktop header (earlier update)
Per your screenshot markup: the desktop header's icon row (Focus Mode /
Share Journey / Setting / Friend Celebration, next to the top-right) now
also has two more round glow-icon buttons, right after Friend Celebration:
- **Analytics** (bar-chart icon) — jumps straight to the Analytics tab
  (`setTab("analytics")`), same tab the "Analytics Summary" widget's
  "Open full" link already opens.
- **Layout** (grid icon) — jumps straight to the Customize Layout tab
  (`setTab("layout")`), same one the mobile FAB's "Layout" shortcut opens.

Both light up (filled state) while their tab is active, same as the
existing icons in that row. Mobile view is unaffected — the mobile FAB
already had both of these shortcuts.

## 🎨 PDF report — no more broken emoji boxes, real icons, new palette, charts on every widget (earlier update)
Two things you flagged from the actual generated PDF, both fixed in
`components/BTLDashboard.jsx`:

1. **Broken "☐ X" boxes where emoji used to be.** pdfmake's bundled font
   (Roboto) has no emoji glyphs at all — every 🔥/✅/🎯/🕒/😊/✔/○ character in
   a text node was rendering as a "tofu" box in the actual PDF viewer, even
   though it looked fine in the editor. Fixed by removing every emoji/unicode
   symbol from PDF text entirely:
   - New `drawSectionIcon(type, color)` draws small, flat, single-color line
     icons on a canvas (checkmark badge, target, clock, flame, smiley, timer,
     dumbbell, wallet, calendar) and embeds them as real PNG images via
     `pdfIconHeading()` — every section/card title is now an icon image + text
     row instead of an emoji character, so it renders identically in every
     PDF viewer.
   - The Daily Goals / Extra Goals / Time Table checklists on the cover page
     now use plain `[x]` / `[ ]` instead of ✔/○ (also font-dependent symbols),
     and no longer use pdfmake's built-in bulleted list (`ul`) either, since
     its bullet marker is drawn from the font too — just plain stacked lines.
2. **New color palette** — every PDF color (headings, card accents, chart
   bars/lines, icons) now comes from
   [coolors.co/palette/2d3142-bfc0c0-ffffff-ee8354-4f5d75](https://coolors.co/palette/2d3142-bfc0c0-ffffff-ef8354-4f5d75):
   `#2D3142` (dark ink/headings), `#4F5D75` (secondary/slate accent),
   `#EF8354` (primary/orange accent), `#BFC0C0` (table hairlines/dividers),
   `#FFFFFF` (card fills). The page **background stays the `#f7f3e3` cream**
   from the previous update, exactly as asked — only what's drawn on top of
   it changed.

Also added: **Daily Goals and Time Table now get their own per-page mini
chart** (`drawMiniPercentChart`), same as Completion already had — a
compact 0–100% bar chart for that page's 15 days, sitting above each
section's detail table (Extra Goals gets one too, for the same reason).

## 📄 Past Data export is now a real, professionally designed PDF (earlier update)
Per your request: the "Past Data" report (Analytics tab → **Past Data** →
Apply) no longer downloads an HTML file you had to open and "Print → Save as
PDF" yourself — it now generates and downloads an actual multi-page **PDF**
directly, built with [pdfmake](https://github.com/bpampuch/pdfmake) (added to
`package.json`, loaded on demand via dynamic `import()` so it never adds
weight to the normal app bundle).

- **Background color**: every page — cover and data pages alike — uses the
  requested `#f7f3e3` cream background (`PDF_BG` in `components/BTLDashboard.jsx`),
  drawn full-bleed via pdfmake's `background` callback.
- **Max 15 days per page**: the selected date range is split into chunks of
  at most 15 days (`chunkDates`/`PDF_DAYS_PER_PAGE`), each chunk getting its
  own page — a range never crowds more than 15 days onto one page, however
  long it is.
- **Chart + full details on every data page**: each page opens with a
  canvas-drawn analysis chart (`drawChunkAnalysisChart`) — completion %
  bars with Focus Timer / Fitness minute trend lines overlaid, whichever of
  those you selected — followed by complete per-day detail tables for every
  selected widget (Mood, Daily Goals, Extra Goals, Time Table, Focus Timer,
  Fitness) and a full Money ledger, all scoped to just that page's 15 days.
- **Cover page**: your photo (fetched and rendered into a circular avatar;
  falls back to an initials avatar if the photo can't be read) and name, plus
  your **current** Daily Goals, Extra Goals, and Time Table lists exactly as
  they stand today — so the report opens with who it's for and what they're
  working on, before diving into the history.
- Professional layout throughout: consistent typography scale, accent-colored
  section headers, clean card blocks (no more relying on `window.print()`'s
  inconsistent per-browser pagination/margins) — same look on every device
  and browser since pdfmake renders the PDF bytes directly rather than
  depending on the browser's print engine.

All of this lives in `components/BTLDashboard.jsx`: the chart/avatar helpers
and `buildPastDataReportDocDefinition` (replacing the old `buildPastDataReportHTML`)
sit just above `PastDataModal`, whose `Apply & Download PDF` button now
`await`s the doc definition and calls `pdfMake.createPdf(docDefinition).download(...)`.

## ⚡ Mobile performance pass — fixing "atak-atak"/hangy animations (earlier update)
Root cause found: the dashboard was mounting **both** the desktop header +
full `WidgetGrid` **and** the mobile topbar/stats/dial UI at the same time on
every device — whichever one didn't apply to the current screen size was
only hidden with CSS `display:none`, not actually removed from the page.
A `display:none` subtree still fully exists in React and still runs every
animation inside it (framer-motion's requestAnimationFrame loop doesn't stop
just because a parent is invisible) — so on a phone you were effectively
running **two full copies of the dashboard** every single frame: the visible
mobile one, plus a hidden desktop one with its own header-logo pulse, 4
infinite glow-icon animations, and the entire widget grid (including
per-second-interval widgets like the analog clock). That's exactly the kind
of invisible, un-debuggable CPU drain that shows up as stutter and hang on
real hardware even though everything looks fine testing in a resized
desktop browser.

Fixes, all in `components/BTLDashboard.jsx`:
- **`useIsMobileView()`** — a `window.matchMedia("(max-width: 768px)")` hook
  that now actually gates which tree *mounts*, not just which one is
  visible. Desktop header + `WidgetGrid` only render at all when
  `!isMobileView`; the mobile topbar/stats/analytics/quick-goals card and
  the radial dial home only render when `isMobileView`. Only one dashboard
  now ever exists in the page at a time, on any device.
- **`glassCardStyle()` lighter on mobile** — `backdrop-filter: blur()` is one
  of the most GPU-expensive things a phone can paint, and this style backs
  nearly every card/widget in the app. Desktop keeps the original
  `blur(20px) saturate(200%)` look untouched; mobile now gets `blur(9px)`
  with no separate `saturate()` pass (one cheap filter instead of two),
  same frosted-glass look at a fraction of the paint cost — this matters a
  lot with a dozen-plus glass cards visible together in the grid.
- **New global perf CSS**: `contain: content` on every widget card (so one
  card re-rendering doesn't force the browser to re-check layout/paint for
  every other card on screen), `-webkit-overflow-scrolling: touch` +
  `overscroll-behavior: contain` on scrollable panels for native momentum
  scroll instead of the default janky WebView scroll, `touch-action:
  manipulation` on buttons/tap targets to drop the ~300ms tap-delay some
  mobile browsers add, and a `prefers-reduced-motion` block that trims the
  purely decorative infinite loops (shine sweep, glow pulses) for anyone
  whose device/OS has asked apps to cut back on animation (some low-RAM
  Android battery-saver modes set this automatically).

None of this touches how anything looks on desktop — every change above
either only fires past the 768px breakpoint or is additive CSS that has no
visible effect on the existing look. If you still feel jank in specific
spots after this (e.g. one particular modal, one particular list), point me
at it and I'll profile that one directly — a real device's dev-tools
performance trace would pin down anything left far faster than guessing.

## ⌨️ Daily Goals / Time Table "Add" bars now keyboard-aware too (earlier update)
Same WhatsApp-style fix as the Friend chat popup, extended to every place
you type into these two widgets — the mobile quick-view toggle card, the
full-screen dial widget panels (`Daily Goal` / `Time Table` back-arrow
screens), and anywhere else `GoalChecklist` / `TimeTable` render their own
"Add item…" / "What to do at this time…" bar: a shared `useKeyboardOffset`
hook (`components/BTLDashboard.jsx`) reads the on-screen keyboard's height
via `window.visualViewport` and shifts that bar up by the same amount, so it
always sits right above the keyboard instead of getting hidden under it.
No-op on desktop.

## 💬 Friend chat popup — full screen on mobile + keyboard-aware input (earlier update)
Per your marked-up screenshot: the "dev saini" chat popup (`FriendChatModal` in
`components/FriendCelebration.jsx`) now opens **full screen only on mobile**
(≤768px, same breakpoint the rest of the app's mobile layout already uses) —
width/height go to `100vw` / `100dvh` and the corner radius drops to 0, purely
via a `@media` block scoped to the modal's own class, so **desktop is
untouched**: it still opens as the original centered glass card at its
original size.

The message input bar also now tracks the on-screen keyboard, WhatsApp-style:
a `window.visualViewport` listener reads how many pixels the keyboard is
currently covering and shifts the input row up by exactly that much
(`translateY`) every time it opens, resizes, or closes — so "Type a
message…" and the send button stay sitting right above the keyboard instead
of being hidden underneath it. This is a no-op on desktop (no on-screen
keyboard, so the offset stays 0 and nothing shifts).

## 📊 Analytics now has a "Fitness Time" section (earlier update)
Guided workouts (Start → select → set time → Apply, see the "Start" update
below) now actually bank the time you spend into `state.fitnessLog`
(`FitnessTab`'s new `logWorkoutTime` — same shape/pattern as the existing
`focusTimer.history`): every finished or cancelled session credits its
real elapsed exercise seconds — not the rest beats or the get-ready
countdown — to today's date under whichever section it came from
(Exercise/Yoga/Pranayama). An early Cancel still banks whatever was
actually completed, it just doesn't count the rest of the queue.

**Analytics → 🏋️ Fitness Time — last 14 days** (right under Focus Time,
same visual language) now shows:
- **Worked out today** / **7-day avg / day** / **Top category · 30d** — three
  stat cards, same layout as Focus Time's.
- A 14-day bar chart of total workout minutes per day.
- A 30-day donut + legend breaking total time down by section (Exercise/
  Yoga/Pranayama), colored to match each section's own accent color from
  the Fitness tab.
- Before you've ever completed a guided workout, this shows a short
  pointer to the Fitness tab instead of an empty chart.

New helpers `computeFitnessBreakdown` / `computeFitnessDailyTotals` /
`fitnessSecondsToday` mirror the existing `computeFocusBreakdown` /
`computeFocusDailyTotals` / `focusSecondsToday` almost line-for-line, just
reading `fitnessLog` and labelling/coloring off `FITNESS_SECTIONS` instead
of user-defined Focus Timer categories.

## 🏋️ Fitness now has a guided, full-screen "Start" workout (earlier update)
Per your marked-up screenshot: added a **Start** button in the Fitness
header, right next to the "Fitness" title (`FitnessTab` in
`components/BTLDashboard.jsx`).

- Tapping **Start** turns whichever grid is open (Exercise/Alt/Yoga/
  Pranayama) into a picker — tap any cards to select them (colored outline
  + checkmark badge, `FitnessCard`'s new `selectable`/`selected` props).
  Tapping **Start** again (now labelled "Selecting…") cancels out of
  picker mode.
- Once at least one card is selected, a floating **OK** button appears
  bottom-right of the grid (the spot from your screenshot) showing the
  count selected.
- Tapping it opens a glass popup (`FitnessTimeModal`) with a minutes/
  seconds stepper for "how long each exercise runs," live-previewing the
  total workout length (including rest) before you commit. **Apply**
  builds the queue from your selected exercises in the order they appear
  in the grid.
- **Apply** first drops you into a **10-second "GET READY" countdown**
  (`GET_READY_SECONDS` in `FitnessWorkoutPlayer`) showing the first
  exercise's name, so there's a beat to get into position before anything
  actually starts — then the guided player below begins from exercise 1.
- That hands off to a full-screen guided player (`FitnessWorkoutPlayer`):
  the current exercise's GIF (gently pulsing) with an animated countdown
  ring, its name, and a peek at what's next — followed automatically by a
  **5-second REST** beat (`REST_SECONDS`) between every exercise before
  the next one starts, all self-calculated from however many exercises
  you picked and the per-exercise time you set. A progress bar and
  "Exercise X / N" counter track where you are in the set, Pause/Resume
  is available, and a **Cancel** button sits top-right the entire time as
  an emergency stop — tapping it exits the workout immediately, no
  confirmation needed. Finishing the last exercise shows a short
  "Workout complete!" screen before closing.
- Nothing about this is saved to Firestore — it's a session-only player
  layered on top of the existing static exercise/yoga/pranayama grids,
  which are untouched when you're not using Start.

## 🔒 Life Story now actually locks behind its password (earlier update)
Until now, setting a password on Life Story (via the profile pill → Account
→ Set Password) only protected the **Reset/Forgot-password recovery flow**
— the diary itself still opened straight to your entries the moment you
tapped the **life story** button, password or not.

Now, if a password is set, opening the tab shows a **lock gate**
(`LifeStoryLockGate` in `components/BTLDashboard.jsx`) first — same glass
card look as the Money Management reset gate — and the entries, Today's
Entry popup, filters, and theme controls are not rendered until the
correct password is entered. A wrong password shakes the card and shows
an inline error instead of letting you through. The back arrow and ✕ on
the lock screen just close the tab, same as always, without needing the
password. It re-locks every time you leave and come back to the tab —
there's no "stay unlocked" — and if you don't set a password at all, the
diary opens straight in like before.

## ⚙️ Friend Celebration's gear icon now opens Setting *on top of* it (this update)
Per your marked-up screenshot of the "dev VS dev" screen: tapping the gear
icon (top-left, next to **← Back**) used to close Friend Celebration first
and *then* open the Setting popup over the plain Dashboard — so you'd
briefly lose the VS screen you were looking at. Now the Setting popup
floats directly on top of whichever Friend Celebration screen you were on
(hub or VS split-screen) and lands on **Theme → Friend Celebration** as
before; closing it drops you right back where you were, VS screen intact.

Technically: the Setting modal's stacking order (`zIndex`) in
`components/BTLDashboard.jsx` is now one level above Friend Celebration's,
and its gear-icon handler no longer closes Friend Celebration first — same
two lines that used to force the app back to the Dashboard, removed. The
header's normal **Setting** button and the Quick-Nav fab still behave
exactly as before, since nothing else in the app used the numbers in
between.

## 🫧 "Liquid Glassic" — a Friend Celebration-only theme option (this update)
Per your two screenshots: **Setting → 🎨 Theme → Friend Celebration** now has
a new **"Liquid Glassic"** toggle card sitting above the existing
Background/Border/Text color rows (`ScopeThemeEditor`'s new `friendPreset`
option, `components/BTLDashboard.jsx`). Unlike the "Panel Theme" presets
above the tabs, this one is scoped to **only** Friend Celebration — turning
it on doesn't touch Dashboard, Analytics, Money, Focus Mode, or anything
else.

Tap it on and the whole Friend Celebration experience — hub, the "You VS
Friend" split-screen, and the **Chat popup** — switches to a soft,
neumorphic/liquid-glass look matching your 2nd (moodboard) screenshot:
- Light, airy canvas + frosted glass cards with the embossed light/dark
  dual "soft-UI" shadow (`GLASSIC_TOKENS` in `components/FriendCelebration.jsx`),
  instead of the default dark glass.
- **Every word renders in black** (`#1c1c1e`) — names, labels, goal text,
  captions, chat messages.
- **Every %/streak/score number stays colored** — the goal-completion
  rings' percentage now reads in the ring's own accent color instead of
  fixed white, so it still pops against the light card.
- **Every money figure stays colored** — Total Earn/Total Spend keep
  distinct green/red values (darkened slightly from the dark-theme
  versions so they stay readable on the light card).
- Inputs, buttons, icon chips (gear/close/back), request rows, the
  Discover list, and the Friends grid all pick up the same light-glass
  material — nothing is left on the old dark styling once it's on.
- The **VS clash intro** animation keeps its text white on purpose (it
  plays over the colored diagonal split panels, not the light canvas, so
  white stays the readable choice there regardless of this toggle).

Stored as `state.theme.friendCelebration.liquidGlassic: true/false`, same
round-trip pattern as every other theme field — flip it off, or hit
**Reset** on the Friend Celebration section, to go back to the original
dark glass look.

Didn't need `liquid-glass-js`: the neumorphic dual-shadow + frosted-blur
look here is plain CSS (`box-shadow` + `backdrop-filter`), same approach
the app already uses for its "Liquid Glass" Panel Theme preset elsewhere —
no new runtime dependency required for this either.

## ⚙️ Friend Celebration now has a direct theme shortcut (this update)
Per your two marked-up screenshots, added a small gear icon (⚙️) at the spot
you circled in both:
- **Friend hub header** (`FriendHubView` in `components/FriendCelebration.jsx`)
  — next to your name/"🎉 Friend Celebration" title, before the ✕ close button.
- **"dev VS dev" split-screen header** (`FriendVSView`) — right after the
  **← Back** button, before the "You VS Friend" title.

Tapping either gear closes the Friend Celebration popup and opens the
**Setting** modal landed directly on **🎨 Theme → Friend Celebration**
(exactly the popup from your 3rd screenshot) — no need to close the popup
yourself and click through **Setting → Theme → Friend Celebration** manually.
The normal **Setting** button (header icon / Quick-Nav fab) still opens on
Dashboard as before; only these two new shortcuts jump straight to the
Friend Celebration theme tab.

## 🫧 Time Table is now a *full* glass card, not just its list (earlier update)
You circled the Time Table widget and asked for it to be "full liquid
glass" — turns out it was the one widget still on the old pattern: only
its inner scrollable list (`components/BTLDashboard.jsx`, `TimeTable`)
was wrapped in `glassCardStyle()`; the "Time Table" title pill above it
and the add-slot row below it sat directly on the page background,
outside the glass. Every other full-card widget (Clock & Alarm, Focus
Timer, Calendar, Analytics Summary) already wraps its *entire* content —
title, body, controls — in one glass panel.

Time Table now matches that: the whole card (title + list + category/time/
text/repeat/add row) is one `glassCardStyle()` panel with 10px padding,
and the inner list lost its own separate border/background so there's
just one glass layer, not two stacked ones. This applies regardless of
which Panel Theme preset is active — it's just the correct amount of
glass for this widget, the same as its siblings; it's naturally most
visible once **Liquid Glass** is the active preset, since that's what
makes cardBg light/translucent enough to show blur clearly.

## 🎛️ Liquid Glass now has manageable Blur / Frost opacity / Soft shadow (this update)
Per the neumorphic soft-UI moodboard you shared: **Setting → 🎨 Theme →
Panel Theme**, once **Liquid Glass** is the active preset, now shows a new
**"Liquid Glass — fine-tune"** row underneath it (`LiquidGlassOptionsRow` in
`components/BTLDashboard.jsx`) with 3 live controls:
- **Blur** — 4–40px slider, how frosted every card reads (default 20px,
  same as before).
- **Frost opacity** — 20–95% slider, or **Auto** to fall back to the
  built-in default (66% on light cards / 56% on dark ones, unchanged from
  before).
- **Soft shadow (neumorphic)** — a checkbox that swaps the single lifted
  drop-shadow every glass card normally uses for the **embossed light/dark
  dual shadow** from your reference image (light top-left, dark
  bottom-right), layered *underneath* the same blur/frost fill — so it
  stays real glass, just with that soft, "pressed into a light-gray
  surface" edge from the moodboard instead of a floating card. (Only
  applies on light cards — a dark card with a light/dark neumorphic pair
  would look inverted, so dark cards keep the normal glass shadow.)

All three save to `state.theme.liquidGlassOptions: { blur, opacity, soft }`
in Firestore, same as every other Theme control, and a **Reset** button
clears them back to the original numbers. `glassCardStyle()` — the one
shared helper every widget/card in the app already renders its background
through — reads these live, so there's no new rendering path: turning the
sliders changes every existing card everywhere at once, exactly like the
Panel Theme presets above it.

Still didn't pull in `liquid-glass-js`: the reference image is genuinely a
*soft-UI/neumorphic* moodboard (flat light-gray surfaces, embossed dual
shadows, no blur) rather than glassmorphism, and the "Soft shadow" toggle
above reproduces that specific look with plain CSS box-shadow layered on
the existing blur — no runtime dependency needed for either half of it.

## 🫧 "Liquid Glass" Panel Theme preset (earlier update)
Added an 8th one-tap preset in **Setting → 🎨 Theme → Panel Theme**, next to
Ocean/Sunset/Forest/Berry/Midnight/Charcoal/Black & White/Glass, named
**Liquid Glass** (`PANEL_THEME_PRESETS` in `components/BTLDashboard.jsx`):
- Unlike **Glass** (which pairs a moody indigo backdrop with white cards),
  **Liquid Glass** uses a soft, light, neutral canvas (`#eef1f5`) with
  near-black text (`#1c1c1e`) and pale off-white widget cards (`#f7f8fa`) —
  matching the light "liquid glass" moodboard you shared (soft shadows,
  frosted panels, dark labels on airy glass).
- No new rendering code was needed for the glass look itself: every widget
  already renders its background through the shared `glassCardStyle()`
  helper (heavy blur + saturate, bright glass-rim border, soft lifted
  shadow), and the dashboard already always animates the colorful
  `LiquidBackground` blobs behind everything. Picking light bg/widget
  colors is enough to turn that *existing* frosted mechanism into this
  exact pale liquid-glass material — so it's fully consistent with every
  other widget, popup, and modal in the app, and it's just as "manageable"
  as the other 7 presets: tap it to apply, fine-tune any individual scope
  (Dashboard/Analytics/Widgets/Money/Focus Mode/Friend Celebration) or
  widget color afterward in the sections below, and hit **Reset** to
  clear it. It also plays nicely with **Setting → Background**, so you can
  still recolor the 4 blob hues under this preset if you want a different
  tint showing through the glass.
- Didn't pull in the `liquid-glass-js` library you linked — its SVG
  turbulence/displacement trick is the same technique this codebase
  already ships natively as `GenieFilterDefs` (used for the genie-open/
  close animations elsewhere), and the frosted look itself only needs
  `backdrop-filter`, which is already in `glassCardStyle()`. Keeping it to
  existing, dependency-free code avoids adding a new runtime package for
  an effect the app can already produce.

## ✨ Life Story — Today's Entry is now a liquid-glass popup (this update)
Redesigned `LifeStoryTab` in `components/BTLDashboard.jsx` per the marked-up
screenshots:
- **"hide" → "today" toggle** (top of the Life Story header, next to the
  title) now opens **Today's Entry as a floating popup** instead of
  showing/hiding it inline in the feed. Click it again (or the ✕ inside,
  or click outside, or press Escape) to close.
- The popup is **full liquid glass**: heavy `backdrop-filter: blur + saturate`,
  a translucent gradient fill, a soft top gloss "sheen" band and a frosted
  border/shadow — matching the reference glass-key look. It genie-opens
  and genie-closes out of the toggle button using the same SVG
  `feTurbulence`/`feDisplacementMap` liquid-warp filter + squeeze/scale
  animation that used to hide/show the inline card (`GenieFilterDefs`,
  reused as-is), just landing on a floating card instead of an inline one.
- It's sized and anchored to sit *inside* the journal area (not a
  full-screen modal) — bottom-right, overlapping the past-entries card,
  same as the layout you sketched.
- **Past-day entries** (every date except today) now render with **no
  card, border, or background at all** — just the date, left-aligned,
  with the story text directly underneath it (`LifeStoryDayBlock`'s new
  `plain` mode). Went through two passes: first a bordered card that hugged
  the content, now removed entirely per your last sketch — plain date +
  text is all that's left. Today's entry is unaffected — it still gets
  its own centered pill + gradient card, but only inside the glass popup.
- **New in Theme (gear icon → "Today's Entry Card"):** two color pickers —
  **Card background** and **Card text** — control only the floating
  popup's own colors, independent from the Page Theme colors above it
  (which still only affect past-day entries). Both feed into the glass
  gradient/border/gloss tinting and the entry text itself, so picking a
  dark background (e.g. black) automatically gives a dark glass card with
  whatever text color you choose, not a white glass panel with a
  mismatched dark card inside it. Saved to `state.lifeStory.theme.todayCardBg`
  / `.todayCardTextColor`; defaults to white background + the normal dark
  text so nothing changes until you open Theme.
- `jump to date → Today` in the filters dropdown now opens the popup
  instead of trying to scroll to an inline block that no longer exists.
- The old `GenieHidable` inline hide/show component is no longer used
  (left in place, unreferenced) — replaced by `LifeStoryTodayGlassPopup`.

## 🧘 New — 7 more yoga poses added (this update)
7 more cards appended to `FITNESS_DATA.yoga` (now 20 total): Reclining
Single-Leg Stretch (Bedtime Pose), Pelvic Tilt Tabletop Pose,
Vasisthasana (Side Plank Pose), Supine Knee Bend Relaxation Pose,
Pavanmuktasana (Wind-Relieving Pose), Tucked Headstand Prep (Sirsasana
Variation), Sirsasana (Headstand Pose). 8 images were sent this round
but one was an exact duplicate of the already-added "Supported
Savasana (Knees Bent)" pose, so it was skipped.

## 🧘 2 more yoga poses added (earlier update)
2 more cards appended to `FITNESS_DATA.yoga` (now 13 total): High
Plank Pose (Full-Body Stretch), Savasana (Corpse Pose). Images added
to `public/yoga/`.

## 🧘 8 more yoga poses added (earlier update)
8 more cards appended to `FITNESS_DATA.yoga` (now 11 total): Ustrasana
(Camel Pose), Constructive Rest Pose, Makarasana (Crocodile Pose),
Virabhadrasana II (Warrior II), Marjaryasana (Cat Pose), Supported
Savasana (Knees Bent), Salamba Bhujangasana (Sphinx Pose), Phalakasana
(Plank Pose). Images added to `public/yoga/`. Same card shape as
before (`id`, `name`, `duration`, `gif`, `steps`, `benefits`).

## 🧘 Fitness → Yoga section populated (earlier update)
`FITNESS_DATA.yoga` was empty before (`yoga: []`, showing the "Yoga
jaldi aa rahe hain" placeholder) — 3 real-photo poses were added:
Ardha Halasana (Half Plow Pose), Navasana (Boat Pose), and Ardha
Sarvangasana (Half Shoulder Stand). Images live in a new
`public/yoga/` folder (kept separate from `public/fitness/` for
clarity). Same card shape as Exercise (`id`, `name`, `duration`,
`gif`, `steps`, `benefits`) — Fitness → Yoga tab now shows these
instead of the empty state.

## 🏋️ 13 more exercises added to Fitness → Exercise (earlier update)
13 more cards appended to `FITNESS_DATA.exerciseAlt`: Forearm Plank
(Fists), Banded Side-Lying Clamshell, Standing Overhead Reach Stretch,
Weighted Toe Reach (Dumbbell), Single-Leg Raise (Lying), Tabletop
Crunch Hold, Seated Single-Leg Stretch, Lying Single-Leg Raise (Hands
Behind Head), Banded Sumo Squat, Straight-Leg Toe Touch, V-Up (Toe
Touch), Prone Single-Leg Raise, Prone Full-Body Reach. 14 files were
sent this round but one was an exact duplicate upload (same GIF twice)
— it was only added once. Total exerciseAlt count is now 64.

## 🏋️ 7 more exercises added to Fitness → Exercise (earlier update)
7 more cards appended to `FITNESS_DATA.exerciseAlt` in
`components/BTLDashboard.jsx`: Figure-4 Stretch (Reclining Pigeon),
Boat Pose Hold (V-Sit), Bicycle Crunch, Scissor Kicks, Superman Reach,
Box Step-Up, Standing Mountain Pose (Posture Reset). Images live in
`public/fitness/` (one is a `.jpg`, rest `.gif` — `<img>` handles both
fine). Two of the images you sent this round (cat-cow-stretch,
seated-leg-extension-bench) were exact duplicates of ones already
added in the previous update, so they were skipped — not added twice.

## 🏋️ 14 more exercises added to Fitness → Exercise (earlier update)
14 new GIFs (mountain climber, standing knee drive, high knee march,
three-legged downward dog, standard plank hold, seated half-split
stretch, lying vertical leg raise, bodyweight squat with hands behind
head, straight-leg raise hold, spiderman plank crunch, dumbbell
pullover, standing wide-stance side bend, cat-cow stretch, seated leg
extension on a bench) were dropped into `public/fitness/` and appended
as new cards to `FITNESS_DATA.exerciseAlt` in
`components/BTLDashboard.jsx` — same shape as every existing card
(`id`, `name`, `duration`, `gif`, `steps`, `benefits`), so they show up
automatically in **Fitness → Exercise** (the "alt" list, toggled with
the swap button) with no other code changes. Exercise names/steps/
benefits were inferred from the GIF poses — say the word if any need
renaming or re-categorizing.

## 🏋️ 19 more exercises added to Fitness → Exercise (earlier update)
19 new GIFs (donkey kick, quadruped leg extension, straight-arm plank,
child's pose stretch, cross-arm crunch, plank knee raise, reclined
knee-bend rest, side-lying relaxation stretch, standing side leg raise,
kneeling forward reach stretch, side-lying knee tuck stretch, vertical
toe-reach crunch, standing march in place, boxer guard stance hold,
flutter kicks, high plank hold, push-up, jogging in place, standing high
knee raise) were dropped into `public/fitness/` and appended as new cards
to `FITNESS_DATA.exerciseAlt` in `components/BTLDashboard.jsx` — same
shape as every existing card (`id`, `name`, `duration`, `gif`, `steps`,
`benefits`), so they show up automatically in **Fitness → Exercise** (the
"alt" list, toggled with the swap button) with no other code changes.
Exercise names/steps/benefits were inferred from the GIF poses — say the
word if any need renaming or re-categorizing (e.g. into Yoga).

## 🎛️ "Background" tab in Settings (earlier update)

The Liquid Background (gradient wash + blobs + particles) is now fully
user-controllable from **Setting → Background**:

- **Colors** — all 4 hues it draws with (previously hardcoded amber/sky/
  coral/sage) are now 4 native color pickers. Changing one updates the
  gradient, the matching blob, and every particle tinted with that hue
  at once, since they all read from the same shared palette. A **Reset
  colors to default** button restores the original 4.
- **Animation speed** — a single 0.4x–3x slider controls how fast the
  blobs drift/morph, the gradient shifts, and the particles move (the
  click-triggered ripple effect is unaffected, since it's a one-shot
  reaction to a click, not a continuous loop). A **Reset speed to 1.0x**
  button restores the original pace.
- Both persist to Firestore on `state.liquidBg: { colors: string[4],
  speed: number }`, same as every other Setting. Old saved states
  without this field fall back to the original hardcoded colors/speed
  automatically — no migration step needed.
- Wave Effect (the old 3 scrolling SVG bands along the bottom edge) has
  been removed entirely from `LiquidBackground.jsx`, including its
  keyframe — it's no longer part of the layered system below.
- The Ripple 3D Effect (the click-triggered expanding wave-interference
  rings) has also been removed entirely — `RippleWaveCanvas`, its color
  constants, and its usage are all gone from `LiquidBackground.jsx`. The
  background is now 3 layers: Liquid Gradient, Liquid Blob, Particle
  Fluid — nothing spawns on click anymore.

## 🌊 "Liquid Background" system (earlier update)

The dashboard's old background was just 3 static blurred circles. It's now
a full animated liquid system, built as its own component
(`components/LiquidBackground.jsx`) and dropped in behind everything —
still `z-index: -1`, `pointer-events: none`, clipped by the dashboard's
own rounded panel, so it never affects layout or intercepts clicks meant
for widgets.

**Root-cause fix (this update):** the dashboard's outer panel only had
`position: relative` with no `z-index`, so it never established its own
CSS stacking context. That meant the `z-index: -1` LiquidBackground layer
wasn't confined *inside* this panel at all — it escaped to whatever
ancestor stacking context existed further up the tree and painted behind
that instead, invisible no matter how the colors/opacity were tuned. Fixed
by adding `zIndex: 0` + `isolation: "isolate"` to the outer panel
(`components/BTLDashboard.jsx`), which forces it to own its stacking
context so the liquid layer now correctly sits between the panel's own
background and its content. If a background layer like this ever again
"exists in the DOM with the right styles but is invisible," this is the
first thing to check — not opacity.

Five techniques, layered (Wave Effect was later removed — see the
"Background" tab section above):
- **Liquid Gradient** — a slow-shifting radial-gradient mesh (4 brand
  hues: amber, sky, coral, sage, now user-recolorable — see above) that
  drifts and rotates on a 26s loop (speed adjustable) — the base wash
  every other layer sits on top of.
- **Liquid Blob** — 4 organic blobs, merged into one melting "goo" mass
  via an SVG `feGaussianBlur` + `feColorMatrix` filter, each morphing its
  own `border-radius` on a 19–27s loop while drifting/scaling — so they
  split apart and re-merge continuously instead of just floating as flat
  circles.
- ~~**Wave Effect** — 3 translucent SVG wave bands along the bottom edge,
  each scrolling at a different speed/direction for a parallax feel.~~
  Removed.
- **Particle Fluid** — a `<canvas>` layer of ~28 soft glowing dots (14 on
  touch devices) that drift with gentle sine-based turbulence, are loosely
  drawn toward the cursor when nearby, and draw faint connective lines
  between neighbors for a "fluid mesh" look — a single shared
  `requestAnimationFrame` loop, torn down on unmount.
- ~~**Ripple 3D Effect** — every click/tap anywhere on the dashboard spawns
  a real wave-interference simulation instead of one fading circle: a
  single continuous radial gradient per ripple whose color stops *are*
  the sine wave and its exponential decay envelope (160 stops — the
  browser's own gradient interpolation renders it as one seamless,
  continuously-blended swell with no visible ring edges, the way an
  actual water ripple looks, not a stack of separate stroked circles),
  colors cycling teal → indigo per crest, drawn with additive
  (`"lighter"`) canvas blending — so when two ripples cross, they don't
  just overlap flatly, they add into a bright interference zone, the
  same look as a real water-ripple photograph. Canvas 2D, not WebGL —
  cheap enough to run continuously, capped at 4 concurrent ripple
  sources.~~ Removed.

Details:
- `LiquidBackground` takes `dark` (computed from the active Panel Theme's
  background via the existing `hexLuminance` helper) so blob/gradient
  opacity and blend mode (`multiply` on light presets, `screen` on dark
  ones) stay legible on every preset, light or dark or Glass.
- Ripple detection listens on the dashboard's own outer ref
  (`dashboardRootRef`, new) via `pointerdown` — no extra DOM wrapper, no
  interference with existing click handlers.
- `prefers-reduced-motion` freezes every animated layer to one still
  frame (gradient/blobs stop, particles render once with no cursor
  tracking, no ripples spawn) — matches the accessibility bar the rest of
  the app already holds itself to.
- `pointer: coarse` (phones/tablets) halves the particle count and skips
  the cursor-attraction math, since there's no persistent cursor there.
- Pure inline SVG + Canvas 2D + `framer-motion` — no new npm installs.
  Purely decorative, no new Firestore fields, no new app state.

### Follow-up tuning (this update)
Two rounds of visibility fixes on top of the initial build, then one
intensity dial-back once it was actually visible:
- All the gradient/blob/wave/particle alpha values were boosted noticeably
  (roughly +50–70%) after the first pass looked too faint against the
  cream/white base — the earlier values were tuned for a flashier dark
  mockup and read as almost invisible on the app's actual light theme.
- The **real bug** turned out to be a CSS stacking-context issue, not
  opacity at all: the dashboard's outer panel had `position: relative`
  but no `z-index`, so it never established its own stacking context —
  meaning the `z-index: -1` LiquidBackground layer wasn't confined
  *inside* the panel, it escaped to whatever ancestor stacking context
  existed further up and painted behind that instead, invisible no
  matter how the colors were tuned. Fixed with `zIndex: 0` +
  `isolation: "isolate"` on the outer panel div in
  `components/BTLDashboard.jsx`. If a background layer like this is ever
  "in the DOM with the right styles but invisible," check this first.
- Once actually visible, the first pass read as too vivid/saturated for
  a data-dense dashboard, so gradient/blob/wave/particle alpha were
  dialed back roughly 40% and the glass-card overlay opacity was nudged
  back up (46%→66% light / 38%→56% dark) for crisper text contrast —
  landing on a softer, still colorful wash instead of a loud one.

## ⏰ New — "Analog Clock & Alarm" widget (earlier update)

A new widget — add it from **Setting → Layout → Add widget → Analog
Clock & Alarm** (or it's already in the default layout on a fresh
install). It's a live analog clock face that doubles as a one-click
alarm setter, plus a matching "ring" popup and a ringtone picker.

- **Real analog clock** — hour, minute, and second hands driven by the
  actual system time (redrawn every second via `AnalogClockWidget`'s own
  `setInterval`), with a 12-number dial and a digital `HH:MM:SS AM/PM`
  readout underneath.
- **Hover-to-preview** — moving the mouse anywhere inside the dial
  computes the angle from center, converts it to a 12-hour-dial reading
  (`clockAngleToTime12`), and shows a small dark popup right next to the
  cursor with that time (e.g. `03:15 · double-click for alarm`).
- **Double-click to arm an alarm** — double-clicking commits that spot's
  time as a real alarm. Since a bare dial position is ambiguous between
  AM/PM, `nearestFutureTime()` picks whichever of the two is soonest
  from right now, so it always arms the *next* upcoming occurrence.
  Armed alarms show as small colored dots on the dial itself and as
  removable chips (tap the ✕) under the clock.
- **Alarms are daily-recurring** — because the dial can't distinguish
  today from tomorrow, an armed `"HH:MM"` simply fires every day the
  live clock reaches it, until it's removed from the widget's chip
  list. New `state.clockAlarms: { id, time }[]`.
- **The ring popup** — `AlarmRingModal`, a glassmorphism card (same
  recipe as Settings/Memories) with a warm pulsing radial-gradient wash
  behind a shaking `AlarmClock` icon, the fired time in large monospace
  text, the active ringtone's name, and a **Done** button to dismiss.
  Rendered at the dashboard's top level so it pops up over whatever tab
  you're on when an alarm fires.
- **Ringtones** — 4 built-in tones (**Classic Beep**, **Gentle Chime**,
  **Digital Pulse**, **Bell Toll**), all synthesized live with the Web
  Audio API (`playRingtoneCycle`/`startAlarmRingtone`) — no audio files
  bundled. The alarm loops its ringtone gapless for **up to 30 seconds**
  (`ALARM_MAX_RING_MS`) or until "Done" is tapped, whichever comes first.
- **Setting → Alarm** (new tab next to Theme) — pick which of the 4
  ringtones plays when an alarm fires, with a ▶ preview button on each
  option so you can hear it before committing. Selection is saved to
  `state.clockRingtone` like the rest of the app's settings.
- Pure `framer-motion` + inline SVG + Web Audio — no new npm installs,
  fits the existing per-user Firestore document (`clockAlarms` +
  `clockRingtone` are just two new fields on the same `btl_state/{uid}`
  doc everything else already lives in).

## 🌍 New — "Earthquake" jitter on checkbox tick (earlier update)

Ticking a checkbox (Daily Goals, Extry Goals, or Time Table) previously
only triggered a color flash / scale pop. Now the whole row around the
checkbox — the checkbox itself, the Time Table rail/line, and the
item's words — briefly "quakes": a fast, decaying left-right/up-down
jitter with a touch of rotation, scoped to roughly the area circled in
the reference screenshot around the checkbox.

- New shared `quakeAnimate(isCelebrating)` helper (next to `GoalChecklist`)
  returns a `framer-motion` keyframe `animate` object — 6-step decaying
  x/y/rotate jitter over ~0.45s — with the peak displacement derived
  from `QUAKE_UNIT` (14px, the checkbox's own width/height) so the shake
  reads as scaled to the checkbox, not an arbitrary wobble.
- Wired into the same `isCelebrating` flag both checklist types already
  use for their "just completed" flash/burst, so it fires automatically
  right when a box is ticked — no new state, no new Firestore fields.
- `GoalChecklist`'s draggable row content (`Daily Goals` / `Extry Goals`)
  and `TimeTableRow`'s content row (checkbox + rail + time + text) both
  now render as `motion.div` with this `animate` applied, so the quake
  sweeps through everything sitting in that row together.

## 💰 Fix — "Total Earn/Spend Money life" pills washed out on light backgrounds (earlier update)

The two header pills next to the logo (**Total Earn Money life** /
**Total Spend Money life**) used `opacity: 0.55` for their "coming soon"
disabled look, on top of an `Oval` whose default background already
matches the dashboard's own background color. On a light Panel Theme
preset, that combination made the pill nearly disappear into the page —
just a faint outline with washed-out green/red text (visible in the
screenshot).

- Both pills now get their own **fixed, always-visible tinted fill** —
  a translucent green wash + solid green border for Earn, translucent red
  wash + solid red border for Spend — instead of inheriting the page's
  own background. This reads clearly on every Panel Theme preset, light
  or dark, without needing per-preset special-casing.
- Dropped the blanket `opacity: 0.55` that was also fading the ₹ amount
  chip inside each pill; the `cursor: "not-allowed"` + "Coming soon"
  tooltip already communicate that these aren't clickable yet, so the
  numbers themselves stay fully legible.

## 🎯 Fix — ring/circle percentage text going invisible on dark presets (earlier update)

The Daily/Extry/Overall percentage rings inside the **Analytics Summary**
widget (and its live preview in Setting → Theme → Analytics Summary) were
reading their text color straight from the *global* dashboard theme
(`DashboardThemeCtx`) instead of from whatever background that specific
ring actually sits on. Under a dark/Glass preset, that global text color
is light — fine on the real dark dashboard, but the Settings preview
renders on a plain white/cream popup, so the percentage numbers came out
near-white-on-white and effectively disappeared (visible in the
screenshot: empty-looking Daily/Extry/Overall rings).

- `RingStat` now accepts an explicit `textColor` override (falls back to
  the dashboard context exactly as before if none is given, so the header
  rings — Daily Goal / Extry Goal / Goal up top — are unaffected).
- `AnalyticsSummaryMetric` now passes its already-computed, background-
  aware `safeTextColor` into `RingStat` for the ring case, the same value
  it already used for the streak/money metrics. Since that color is
  computed from the metric's actual `cardBg` (via `autoTextColor`), it's
  now correct in both places: dark and legible in the Settings preview
  (no `cardBg` there → falls back to the app's default dark text), and
  still auto-contrasted against whatever color the widget has on the real
  dashboard.

## 🪟 Fix — glass cards looked like flat/muted solid colors, not glass (earlier update)

Picking the new Glass preset (or any preset really) still rendered widgets
as a fairly flat, opaque-looking color patch instead of true frosted
glass — compare to the app's own `LifeStoryProfileSetup` "Start your Life
Story" popup, which already nailed the look. The difference was the
recipe, not the concept:

- `glassCardStyle()` (used by every widget/panel, see previous update) now
  matches that popup's exact recipe: **stronger blur** (16px → 24px) with
  a bigger **saturate boost** (150% → 190%), a **bright semi-opaque white
  edge highlight** border instead of a barely-there tinted one (this is
  the single biggest tell for "glass" vs. "muted color" — it's the rim
  light every real glass/frosted surface catches), and a **much bigger,
  softer lifted shadow** (8px/28px → 20px/50px) so the card visibly
  floats above the page instead of reading as a slightly-transparent flat
  fill sitting flush with the background.
- No other change needed — this one shared helper feeds every widget,
  the full-screen Analytics/Money/Focus Mode panels, and the Friend
  Celebration cards from the previous update, so all of them pick up the
  fix together.

## 🥂 New — full "Glass" Panel Theme + glassmorphism extended to every panel/widget (earlier update)

Previously, the frosted-glass ("Glassmorphism 2.0") treatment only applied
to 4 widgets — Daily Goals, Extry Goals, Time Table, Calendar. Everything
else (Life Big Goals, Life Rules, Earn Money/Notes, Analytics Summary, the
full Analytics screen, Money Management, and Focus Mode) still rendered as
a flat, opaque color card.

- **Every remaining panel/widget now renders through the same
  `glassCardStyle(cardBg)` helper** — semi-transparent fill + `backdrop-filter:
  blur(16px) saturate(150%)` + an auto light/dark border and shadow — so
  **no widget or full-screen panel anywhere shows a flat opaque color
  anymore**, on any Panel Theme preset (Ocean, Sunset, Forest, Berry,
  Midnight, Charcoal, Black & White). Converted: `TextList` (Life Big
  Goals / Life Rules), `EarnMoneyNotesCard`, `AnalyticsSummaryWidget`, the
  full-screen `AnalyticsTab`, `MoneyManagementScreen`, and Focus Mode's
  container (when it has a custom background). Their header strips now
  sit transparently on top of that same blurred card instead of drawing a
  second flat-colored bar.
- **New 8th Panel Theme preset — "Glass"** — sits in the same one-click
  **Panel Theme** row (Setting → 🎨 Theme) as the other 7. Instead of a
  flat tinted background, it pairs a deep indigo canvas (`#2b2f52`) with a
  pure-white `widgetBg` — since every card now renders through
  `glassCardStyle`, that white becomes true frosted glass floating over
  the indigo, the closest match in this stack to Apple's "Liquid Glass"
  language. Like every other preset, picking it writes into the exact
  same `bg`/`text`/`widgetBg` fields — no new theme schema.
- **Text stays perfectly legible everywhere** — this reuses the existing
  `autoTextColor`/`autoMutedColor` helpers unchanged (they already read
  whatever `cardBg` a widget has and flip between light/dark text based on
  its brightness), so every one of the newly-glassy cards keeps
  auto-contrast text exactly like the original 4 always did — nothing
  extra to configure, including under the new Glass preset itself.
- Also added real `backdrop-filter` blur to Friend Celebration's Invite,
  Your Friends, and VS-dashboard cards, which were already
  semi-transparent (`rgba(255,255,255,…)`) but previously had no blur
  behind them — they're now true frosted glass too, matching the chat
  popup, which already had it.
- Pure CSS — no new npm installs, no new Firestore fields.

## ✨ New — "system intelligence" micro-interactions on Daily Goals / Extry Goals (earlier update)

Two small but noticeable interactions on the **Daily Goals** and **Extry
Goals** cards (both use the same `GoalChecklist` component):

- **50%-subtask progress nudge** — the moment a goal's subtasks cross
  from under half done to half-or-more done (and it isn't fully done
  yet — that already has its own full "done" celebration flash), a
  small pill reading **"✨ Halfway there"** pops onto that row's
  top-right corner for about 1.5s, then fades. Tracked via a
  per-goal last-seen-ratio ref (`subtaskRatioRef`) inside
  `GoalChecklist`, compared each time the `items` prop updates — purely
  a UI nudge, doesn't touch stored state.
- **Swipe-to-complete on mobile** — on a touch device (phones/tablets,
  detected via `(pointer: coarse)` through the new `useIsTouchDevice()`
  hook), a goal row can now be **swiped right to mark it done**, or —
  if it's already done — **swiped left to undo**, in addition to the
  checkbox (which still works exactly as before, on every device). As
  you drag, a green check (or red undo) reveals behind the row with
  opacity tied to drag distance; release past ~60px to commit, short of
  that and it springs back. **Desktop mouse users see zero change** —
  drag is entirely disabled (`drag={false}`) unless a coarse pointer is
  detected, so no existing click/hover behavior on the row (icon
  picker, expand chevron, delete) is affected.
- Both are pure `framer-motion` + a bit of local state — no new npm
  installs, no new Firestore fields (the nudge and drag offset are
  transient UI state, not persisted).

## 🌫️ New — Glassmorphism 2.0 on Daily Goals / Extry Goals, Time Table & Calendar cards (earlier update)

The three checklist-style cards on the dashboard no longer render as a
flat, fully-opaque cream fill — they now use a frosted-glass look:
semi-transparent background + backdrop blur, a soft ambient shadow,
and a subtle inner highlight for depth.

- Applies to: **Daily Goals**, **Extry Goals** (both share the same
  `GoalChecklist` component), **Time Table**, and **Calendar**.
- New `glassCardStyle(cardBg)` helper (next to the existing
  `autoTextColor`/`autoMutedColor` helpers in `components/BTLDashboard.jsx`)
  takes whatever color is already sitting in that card's `cardBg` — the
  app's default cream, a per-widget custom color from Setting → Theme →
  Widgets, or a color written in by a Panel Theme preset — and renders
  it at ~55% opacity with `backdrop-filter: blur(16px) saturate(150%)`
  behind it, plus a shadow/border that automatically switches between a
  light-mode and dark-mode look based on that same color's brightness
  (reusing the existing `hexLuminance` check). **No new theme fields or
  settings needed** — same pattern as the auto-contrast text fix above.
- Pure CSS (`backdrop-filter`), no new npm installs. Support is ~97%
  across browsers; on the rare browser without it, the card just shows
  its semi-transparent color without the blur — still readable, just
  slightly less "frosted."

## 🖼️ New — browser tab / app icon added (earlier update)

The browser tab (favicon) and home-screen icon now show a custom "B"
monogram mark — dark badge, cream "B" wordmark, small orange spark
accent — matching the app's existing dark + orange color language.

- `app/icon.svg` — Next.js App Router auto-picks this up as the site
  favicon, no `<link>` tags or `layout.jsx` changes needed.
- `app/apple-icon.png` (180×180) — iOS "Add to Home Screen" icon,
  auto-detected the same way.
- `public/favicon.ico` — classic multi-size fallback (16/32/48/64px)
  for older browsers and bookmark bars.

## 🛠️ Fix — colors weren't legible on dark Panel Theme presets + 7th "Black & White" preset added (earlier update)

**Bug fix:** picking a darker Panel Theme preset (Midnight / Charcoal)
correctly changed every card's *background*, but a lot of body text —
the header's Daily/Extry/Overall goal-ring numbers, the Day Streak
area, Daily Goals / Extry Goals list text, Life Big Goals / Life
Rules list text, the Analytics Summary widget's numbers, Calendar day
numbers, and the "Today's Mood" label — was hardcoded to the app's
original dark brown/black text color. On a light preset that's
invisible-on-invisible... on a *dark* preset it went dark-text-on-
dark-card, which is what was making colors feel "not managed
properly."

- Every one of those spots now **auto-computes its own text color**
  from whatever background it's actually sitting on (its own widget
  color, or the Dashboard scope color for header elements) — light
  text on a dark card, dark text on a light card, automatically, with
  no extra setting to configure. This applies whether the color came
  from a Panel Theme preset, a per-widget custom color, or a manual
  pick in any of the Theme tabs (Dashboard / Analytics / Widgets /
  Analytics Summary / Money Management / Focus Mode / Friend
  Celebration) — all of them already write into the same `bg`/`text`
  fields this fix reads from, so no new theme fields were needed.
- **New 7th preset — "Black & White"** — pure black background, white
  text, near-black widget cards. Sits alongside the existing Ocean /
  Sunset / Forest / Berry / Midnight / Charcoal presets in the same
  one-click **Panel Theme** row at the top of Setting → 🎨 Theme.

## 🎨 New feature — 6 one-click "Panel Theme" presets in Setting → Theme (earlier update)

A new **Panel Theme** row now sits at the very top of **Setting → 🎨
Theme**, above the existing Dashboard / Analytics / Widgets / Money /
Focus Mode / Friend Celebration tabs.

- **6 ready-made color patterns** — Ocean, Sunset, Forest, Berry,
  Midnight, Charcoal — each shown as a round two-tone swatch button.
  Tapping one **instantly recolors the whole panel in one go**:
  Dashboard, Analytics, Money Management, Focus Mode, Friend
  Celebration (background + text color for all five) *and* every
  widget's background — all applied together, not one section at a
  time.
- The active preset gets a checkmark + highlighted ring so it's clear
  which one is currently applied, plus a **Reset** button next to the
  row that clears it back to the app's original look everywhere at
  once.
- This sits *on top of* the existing per-section Theme editors — they're
  untouched and still work exactly as before, so after picking a preset
  you can still open, say, "Money Management" and fine-tune just that
  one section's background/text/font further, or tweak a single
  widget's color in the Widgets tab.
- Stored as `state.theme.panelPreset` (which preset, if any, is active)
  alongside the existing per-scope `bg`/`text` values it writes into —
  saved to Firestore per-user like the rest of `state.theme`, so it
  persists across devices/sessions same as everything else in Settings.
- No new npm installs — reuses the same `framer-motion` swatch-button
  pattern already used throughout the Theme panel.

## 🎉 New feature — Friend Celebration (invite, VS dashboard, live chat, friend's Memories) (earlier update)

A new **red 👥 "Friend Celebration" icon** sits in the header, next to
Setting. Clicking it opens a **full-screen panel** — not a small modal —
with a dramatic **"VS" clash animation** (two avatars zoom in from either
side and collide with a flash + "VS" text) every single time it opens.

- **First screen (the "hub")** — your name/avatar up top, an **Invite a
  Friend** box (type their email → they must already have signed into
  BTL once), a live **Requests** list of anyone who's invited *you*
  (Accept ✓ / Decline ✕), your own pending **Sent** invites (cancelable),
  and a grid of **Your Friends** you can tap into.
- **Accepting a request** (by you, or by the person you invited) creates
  a `friendships/{uidA_uidB}` doc. If you're sitting on the hub when the
  *other* person accepts, the app **auto-jumps straight into the VS
  screen** with a fresh VS animation — no refresh needed.
- **The VS split-screen dashboard** (opened from "Your Friends", or
  automatically as above) shows **you vs. your friend side by side**:
  avatar, Total Earn/Total Spend chips, 5 small ring stats (Daily /
  Extry / Overall / Streak / Score), and read-only **Daily Goals** +
  **Extra Goals** lists for each of you, live from Firestore.
- **Chat button** (top center) opens a **glassmorphic chat popup**
  (blurred dark glass, colored message bubbles, spring pop-in) — real
  real-time messaging with your friend, stored per-friendship.
- **Memory button** on your friend's side opens the **exact same
  Memories modal** the rest of the app already uses (tabs for Goals /
  Money / Photos / Notes, date timeline) — just fed with your friend's
  live data instead of yours, and read-only (their notes box is hidden).
- Built entirely with `framer-motion` + `lucide-react` (both already
  dependencies) — **no new npm installs**.

**New files:** `lib/friendsStorage.js` (all the Firestore calls for
requests/friendships/chat) and `components/FriendCelebration.jsx` (the
whole UI). `components/BTLDashboard.jsx` only changed by: exporting
`MemoriesModal` (so the friend-memory view can reuse it), adding the
header icon + badge, and rendering `<FriendCelebration />` alongside the
other modals.

⚠️ **You must redeploy `firestore.rules`** for this to work — new rules
were added for `users_public`, `friend_requests`, `friendships`, and
`friend_chats/{id}/messages`, plus your own `btl_state/{uid}` read rule
was relaxed so an *accepted friend* (and only an accepted friend) can
read your dashboard data for the VS screen. Go to **Firestore Database →
Rules** in the Firebase console, paste the new `firestore.rules`, and
click **Publish** — the app will otherwise get permission-denied errors
on this feature (everything else keeps working as before).

## Header — brand title, streak badge, goal rings & avatar now animated (earlier update)

More header polish, same "alive not static" treatment as the icon
buttons:

- **"Byound The Life" brand pill** — a slow breathing scale loop plus a
  soft pulsing glow ring behind it, so the header's anchor point draws
  a little attention without being distracting.
- **Day Streak badge (the "001" circle)** — now has a looping orange
  glow pulse (streak/fire themed) and scales up slightly on hover.
- **Goal rings (Daily/Extry/Overall)** — the progress arc now animates
  in with a spring (instead of a flat CSS transition) whenever the
  percentage changes, the whole ring lifts + scales a touch on hover,
  and any ring that hits **100%** gets its own looping colored glow as
  a small celebration.
- **Profile avatar** — same soft pulsing glow ring + hover lift/scale
  as the other header buttons, so it matches the rest of the row.
- All built with `framer-motion` (`animate`/`whileHover` loops and
  spring transitions) — no new npm installs, no layout changes to
  anything these components are used in elsewhere (RingStat is shared
  by Analytics/Money summaries too, so those pick up the same
  animated-fill + 100%-glow behavior for free).

## Header — Focus Mode / Setting are now icon buttons + new Share Journey icon (earlier update)

- **Focus Mode** and **Setting** in the header no longer show as text
  pills — they're now small **circular icon-only buttons** (name shows
  as a native tooltip on hover, not as visible text), each with a
  soft **pulsing glow ring** looping behind the icon so they read as
  "alive" rather than flat static buttons. Lift + scale on hover,
  spring squash on tap — built with `framer-motion`, no new npm
  installs.
- **New "📤 Share Journey" icon** added right next to them — tapping it
  opens the same Share Your Journey card (Life Score, Earn/Spend,
  Today's Goals, Today's Notes) that was previously only reachable from
  the Analytics tab, so you can generate + download it straight from
  the main dashboard header now too.
- Internally, the Life Score formula used by that card was pulled out
  into a shared `computeLifeScore()` helper so both the Analytics tab
  and this new header button compute the exact same score — no
  duplicated logic, no drift between the two.

## Header — Total Earn/Spend pills stacked, amounts bold + highlighted (earlier update)

The **"Total Earn Money life"** and **"Total Spend Money life"** pills in
the top header used to sit inline in the same crowded row as
Goals/memor/life story. Now:

- They're **stacked one above the other** (Earned on top, Spent below)
  in their own small column, instead of squeezed sideways into the row.
- The **₹ amount itself** is now **bold** and sits in its own small
  rounded highlight chip — green tint for Earned, red tint for Spent —
  so the numbers are easy to spot at a glance instead of blending into
  the label text.
- Pure layout/styling change — same `state.totalEarnLife` /
  `state.totalSpendLife` values, same "Coming soon" tooltip, nothing
  else touched.

## Earn/Spend widget — "Done" button no longer wipes today's saved note (earlier update)

**Bug fix:** typing a note in the Earn/Spend widget and tapping **Done**
was instantly erasing it from `dailyLogs[today].notes` — the exact
field **Memories → Notes** reads from. So the note vanished the moment
you hit Done, and Memories always showed "Nothing written for this day
yet," even right after writing something.

- `Done` now only clears the widget's own draft textarea + photo
  preview (a fresh blank box, same as before), and **no longer touches
  `dailyLogs[day].notes`**. Whatever you typed stays saved for today,
  so it now shows up correctly in **Memories → that day → Notes**.
- If you keep typing a new note afterward (same day), it live-syncs and
  overwrites the saved note as normal — same behavior as before this
  fix, just without the accidental wipe on Done.
- The Share Your Journey card's "Today's Notes" box (previous update)
  already had a fallback to `dailyLogs[today].notes`, so it now shows
  the correct saved note after Done too.

## Share Your Journey card — Earn/Spend redone, notes replace the quote (earlier update)

Reworked the generated **Share Your Journey** image (Canvas 2D card):

- **Removed the old "Total Earned" stat pill** from the 4-stat row (it
  was cramped and only showed earnings, not spending).
- **New dedicated Earn & Spend panel** right below the Life Score ring:
  two proper side-by-side cards — 💰 **Earned Today** (green) and 💸
  **Spent Today** (red), sourced from `state.moneyHistory[today]` (the
  same per-day aggregate the Money Management trend chart already
  uses) — not the lifetime totals — plus a **Net Today ₹X** readout
  centered underneath.
- **Bottom quote box now shows today's notes instead.** The old
  hardcoded/`lifeRules` quote ("Wake up at 5 AM", etc.) is gone; that
  box now reads straight from `state.notes` (same field the Earn/Spend
  widget's notes textarea writes to), rendered in **bold black** text.
  If there's nothing written yet today, it shows a plain "No notes
  added today" placeholder instead.
- No schema changes, no new npm installs — still pure Canvas 2D reading
  fields the app already tracks.

## Earn/Spend widget — a "Done" button to clear today's notes + photo (earlier update)

Right below the notes box + photo upload square (the circled area) in
the Earn/Spend Money widget, a green **"Done — clear notes & photo"**
button now shows up as soon as either one has something in it.

- Tap it and both clear instantly — the notes textarea empties and the
  photo preview square goes back to the placeholder icon.
- It's saved right away through the same `update()`/Firestore sync
  path everything else in the app already uses, so it stays cleared
  after a refresh — this isn't just a local/visual reset.
- Doesn't touch anything in **Memories** — past photos there live in
  `dailyLogs[day].images` (a separate running list), untouched by this.
- The button fades in/out with its own tiny height animation (`framer-
  motion`, already a dependency) instead of just popping in — no new
  npm installs required.

## Share Your Journey — full pro upgrade: your name + today's goals list (earlier update)

The **Share Your Journey** card (Analytics tab → "📤 Share Journey") got a
complete overhaul:

- **Your name, front and center** — the card's headline is now
  `"{Your Name}'s Journey"`, pulled straight from your signed-in Google
  account (falls back to your Life Story profile name, then "My
  Journey" if neither is set).
- **Today's Goals — full breakdown.** A new section lists every goal
  from both Daily Goals and Extra Goals for today, split into two
  panels side by side:
  - **✅ Completed** — green check markers, with each goal's category
    color-dot next to it.
  - **⏳ Pending** — hollow red-tinted markers for what's still left.
  - A 4th stat pill ("📋 Today's Goals — X/Y") joined the existing
    Day Streak / Total Earned / Top Category row.
  - Long lists cap at 8 rows per side with a "+N more" so the image
    never gets absurdly tall; the card's height is computed dynamically
    off how many goals you actually have, so nothing ever gets cropped.
- **Pro-level modal, with animation:**
  - Spring pop-in/out on open and close, backdrop blur.
  - A live "{name} · X/Y goals done today" chip above the preview.
  - A shimmering skeleton while the card renders (instead of a bare
    "Generating…" line).
  - New **Copy** button (copies the PNG straight to your clipboard,
    next to Download/Share) — only shown on browsers that support it.
- Still pure Canvas 2D + `framer-motion` (both already in the project)
  — no new npm installs required.

## Life Story — hide today's entry with a macOS "genie" effect (earlier update)

A small **hide / show** toggle now sits right next to the "Life Story"
title in the header. Tap it and today's writing box gets sucked away
into that button with a macOS-dock-style **genie** minimize animation
— tap again and it unfurls back out from the same spot.

- Only **today's** box is affected — past entries stay exactly as they are.
- While hidden, a small dashed "Today's entry is hidden — tap to bring
  it back" pill sits in its place, so it's obvious it's just tucked
  away, not deleted.
- Built with an SVG `feTurbulence` + `feDisplacementMap` ripple filter
  (triggered via SMIL `beginElement()`) for the liquid "neck" warp,
  layered under `framer-motion`'s imperative `animate()` (already a
  project dependency) driving the bulge-then-pinch scale/translate
  toward the button. No new npm installs required.
- Note: the reference you linked (`alexwidua/genie`) is a Swift +
  Metal shader built for native iOS/macOS apps — it can't run inside a
  Next.js/React web page, so this recreates the same visual result
  using web-native primitives instead of porting that code directly.
- Nothing is saved to Firestore for this — it's a per-session UI
  toggle, so today's box shows again by default next time you open
  the app.

## Life Story — animated shimmer border (earlier update)

The old day-card border (`1px solid #ece7d8`) was almost invisible against
the cream background — barely showed where the writing box actually was.
Fixed by rebuilding it as a proper animated gradient border:

- A 2px gradient ring (orange → soft gold → blue → orange) now wraps
  every day card, clearly outlining it against the page background.
- The gradient **slowly shimmers/travels** around the border on a loop —
  faster on **today's** entry (5s) than on past entries (9s), so the box
  you're actively writing in draws a bit more attention.
- Today's card also carries a soft accent glow (`box-shadow`) so it reads
  as the "active" one at a glance.
- Built by animating `backgroundPosition` on a `background-size: 300%`
  gradient via `framer-motion`'s `animate` — not animating the `border`
  property directly, which the animation performance guidance for this
  stack calls out as expensive; this keeps it GPU-friendly. No new npm
  installs required.

## Life Story — select-to-format toolbar (earlier update)

Highlight any word or sentence inside **today's** entry and a small
floating toolbar pops up right above the selection — no need to open the
page-wide Theme settings for a one-off change:

- **Bold**, **Italic**, **Underline** buttons.
- **7 quick color swatches** + a full custom color wheel (native color
  picker) for that selection only.
- Works together with the page-wide Theme (font/size/bg) — this toolbar
  only touches the exact text you've selected, so you can bold one word
  and leave the rest alone.
- Formatting is written straight into the entry's saved HTML (same
  `dangerouslySetInnerHTML` already used to render past entries), so it
  shows up correctly the next time you open the app too.

Built with `document.execCommand` (`bold`/`italic`/`underline`/
`foreColor`) — the same approach this file already used for
paste-as-plain-text — applied only to the live selection, so no new npm
installs required.

## Life Story — page theme settings (earlier update)

A **theme** button now sits next to **filters** in the Life Story header.
Tapping it opens the same glass popover style as the rest of the app, with:

- **10 preset themes** — Classic, Midnight (black paper, white text),
  Sepia, Ocean, Sunset, Forest, Rose, Lavender, Slate, Pure Mono — each
  shown as an "Aa" swatch so you see the look before picking it.
- **Font** — 12 options (Default, System Sans, Georgia, Times New Roman,
  Garamond, Palatino, Bookman, Verdana, Trebuchet MS, Tahoma, Courier
  typewriter, Comic Sans), all web-safe stacks — no new npm installs or
  font files to load.
- **Text size** — an 11–22px slider.
- **Bold text** — a single on/off toggle applied to every entry.
- **Text color** and **page background color** — native color pickers, so
  any custom combination is reachable beyond the 10 presets (picking
  either one switches the preset indicator to "custom").
- **Reset to default** — one tap back to the app's normal cream/dark look.

Applies to the whole Life Story page background and every day's story
text (today's editable entry + all past entries). On dark presets like
Midnight, the day cards themselves also switch to a subtle light-on-dark
glass tint automatically, so text stays readable instead of dark-on-dark.

Saved at `state.lifeStory.theme` — same per-user Firestore sync as
everything else, so it persists across devices and sessions. Built with
`framer-motion` for the popover, matching the Jump-to-date popover
already in this tab — no new npm installs required.

**Bug fix (this update):** typing an entry, adding/removing a photo, or
setting up your Life Story profile was silently wiping the saved theme
back to default. Root cause: those four save paths each rebuilt the
`state.lifeStory` object from scratch and forgot to carry the `theme`
field along — so the very next keystroke after picking a theme reset it.
All four now preserve `theme` explicitly. Verified: pick a non-default
theme, type text, add a photo, remove a photo — theme stays exactly as
set in every case.

## Profile avatar + account popup (earlier update)

A round **profile avatar** now sits in the header's top-right cluster —
right where the plain sign-out icon used to sit on its own, next to the
Day Streak badge and the Daily/Extry/Overall goal rings. Tapping it fans
open a **Glassmorphism 2.0 popup** (same blur/border/shadow recipe as the
Memories and Money glass modals, spring entrance/exit) that drops down
from that same top-right corner, over the Earn/Spend Money and Analytics
Summary widgets underneath:

- **Signed in** — shows your Google photo (or a colored initial if you
  have none), display name, email, and a "Signed in with Google" badge,
  plus a **Sign out** button (moved here from the old standalone icon).
- **Not signed in** (edge case — `AuthGuard` already keeps signed-out
  users on `/login` before they ever reach `/dashboard`, but the popup
  handles it gracefully anyway) — shows a single **Continue with
  Google** button. Firebase's Google OAuth creates the account
  automatically the first time someone uses it, so one button covers
  both **login and signup** — no separate signup form is needed.
- Clicking anywhere outside the popup closes it.

Built entirely with `framer-motion` (already a project dependency) — no
new npm installs required.

## Memories — Money tab now shows "where it went" + photos (earlier update)
The **Memories → Money** tab for a day used to only show the Earned/Spent/
Net totals + two bars. It now also lists every individual earn/spend
entry logged that day, straight from `state.moneyEntries`:

- Green ⬆ for earnings, red ⬇ for spends, with the spend's category chip
  (🍔 Food, 🚗 Transport, etc.) so you can see exactly what the money was
  for — matches the category system already used in the Spend Money
  popup / Money Management tab.
- The note typed on that entry, if any.
- **The attached photo, if one was added** (earn or spend can both carry
  a photo via the existing drag-and-drop/tap-to-browse upload) — shown
  as a small thumbnail, tap to open in the same full-screen lightbox the
  Photos tab already uses (download button included).
- Rows fade/slide in with a staggered entrance, same glass-card style as
  the rest of the Memories modal.
- The **Money** tab's badge count now reflects the number of entries
  that day, not just "has money y/n".

No schema change — every entry already had `category`/`note`/`image` on
it (used by Money Management); this just surfaces them per-day inside
Memories too. No new npm installs required.

## Analytics tab — "Deep Analytics" (this update, 8 new pro widgets)

A new **🔬 Deep Analytics** section at the bottom of **Analytics & Insights**,
below the Money nav card. Every widget is computed from data that already
exists in `state` — nothing fabricated:

1. **Category performance** — animated bar per goal category (Health,
   Money, Career, Relations, Personal, Other), done/total + completion %.
2. **Priority performance** — same, split by High/Medium/Low priority.
3. **Best & toughest weekdays** — a bar chart of average completion by
   day of week (last 13 weeks of `completionHistory`), best day in green,
   toughest in red.
4. **Streak record** — current streak (`state.streak`) side-by-side with
   your longest-ever run of ≥70%-complete consecutive days, with a 🏆
   callout when you're on your all-time best.
5. **Mood distribution** — a donut of Happy/Neutral/Sad across every
   logged day in `moodLog`.
6. **Money velocity — last 14 days** — a combo chart (earn bars, spend
   bars, net line) from `moneyHistory`, plus the net change vs. the
   previous 14-day window.
7. **Subtask completion** — a radial progress ring over how many
   subtasks (across every goal) are checked off.
8. **Weekly momentum** — this week's average completion vs. last week's,
   with an up/down callout — the same comparison Smart Insights already
   makes in text, now as its own visual.

Every card fades/slides in with a staggered spring on open and lifts
slightly on hover; bars, the radial ring, and chart series animate in
rather than snapping into place. Colors are pulled from the app's own
palette (category colors, priority colors, `C.accent`/`C.blue`/`C.dark`)
so nothing clashes with the rest of the theme. Empty-state widgets (e.g.
no subtasks yet, fewer than 2 weeks of history) show a short explainer
instead of a blank/misleading chart. Built with `framer-motion` and the
`recharts` primitives already used elsewhere in this file — no new npm
installs required.

## Quick-nav floating button — Money Management shortcut (this update)
The quick-nav fan-out (bottom-right corner) now has a 6th button: a
**Money Management** shortcut with a wallet icon (orange, matching the
app's money accent color), jumping straight to that tab. Order is
memor → Focus Mode → Layout → Analytics → Money Management → Setting.

## Quick-nav floating button (earlier update)

A round arrow button now sits in the bottom-right corner of the
dashboard card (visible on every tab). Tap it and it fans out — one at a
time, staggered — into round icon buttons for **memor**, **Focus Mode**,
**Layout**, **Analytics**, and **Setting**; tap any one to jump straight
there. The **Layout** and **Analytics** buttons have been removed from
the top header bar (Focus Mode, memor and Setting remain there) since
the quick-nav button now covers them. Built with `framer-motion`, no new
npm installs required.

## Drag-and-drop image upload (this update)

Every image-attach spot in the app now also accepts **drag-and-drop**,
not just tap-to-browse:

- **Money Today's "Image Upload"** (the small square next to the notes
  box) — drag a photo straight onto it; it highlights green while
  dragging over.
- **Earn Money popup** — the "Attach a photo" dropzone now also accepts a
  dragged file (still optional).
- **Spend Money popup** — same, on the receipt/bill photo dropzone.

Dragging over any of these shows a green highlight and, where there's
helper text, it switches to "Drop to attach" while hovering. Dropping a
non-image file still shows the same "Please pick an image file" alert as
picking one manually. No new npm installs required — plain HTML5 drag-
and-drop events (`onDragOver`/`onDrop`) wired into the existing upload
logic, so behavior (resizing, compression, size limit) is identical
either way you attach a photo.

## Money Management — Earn Money not persisting (this update, real fix)

Found and fixed the actual root cause of **Earn Money silently not
saving**: every earn entry was being written with `category: undefined`.
Firestore's `setDoc()` **rejects the entire write** whenever any field —
even a nested one inside an array — is `undefined`. That meant:

- The earn amount briefly showed up in the browser tab (local state
  update), making it *look* like it worked.
- The save to Firestore silently failed (only logged to the browser
  console).
- Because saves resend the whole `state` document, **every save from
  that point on also failed** — including totals, goals, everything —
  until the page was refreshed and the unsaved earn entry was gone.

Fix: earn entries now simply omit the `category` field instead of
setting it to `undefined` (spend entries still get a real category
string, unaffected). Verified end-to-end — added an earning, forced a
save, reloaded the app fresh from the (mocked) database, and the total
now correctly survives the reload instead of reverting to ₹0.

## Money Management — Spend "Done" button bug fix (earlier update)

Fixed a real bug: in the **Spend Money** popup, tapping **Done** without
first picking a category did nothing — the button was silently disabled
with no explanation, so it looked like money simply wouldn't add. Now:

- **Done** stays clickable at all times.
- Tapping it without a category shows a clear red warning — **"⚠️ Ek
  category select karein, tabhi entry add hogi."** — with a shake
  animation and a red outline around the category grid, so it's obvious
  what's missing.
- Picking a category clears the warning immediately, and **Done** commits
  the entry exactly as before.

No new npm installs required for either fix.

## Money Management — per-element custom colors (this update)

Same idea as the Analytics element colors below, now for **Money
Management**. **Setting → 🎨 Theme → Money Management** is a new section
with two cards:

1. **Background/text (top card)** — same background color, text color,
   text size, bold and font controls every other scope (Dashboard,
   Analytics, Focus Mode) already has. Setting a **background color**
   here recolors the whole Money Management panel, header bar, and the
   Spend by category / Earn vs spend / Recent activity cards (they're
   transparent over the panel background, so they follow it automatically).
2. **Element colors (second card)** — one independent custom-color
   swatch for every distinctly-colored piece of the screen:

- Header title ("Money Management")
- Section headings ("🏷️ Spend by category", "📈 Earn vs spend", "🕒 Recent
  activity")
- "Total Earned" / "Total Spent" / "Net (life)" / "Entries logged"
  summary cards (each independent)
- "Earn vs spend" chart — Earned bars, Spent bars, and the Net trend
  line, each its own swatch
- Recent activity — the earn-entry icon/amount color and the spend
  amount color

As before, every field defaults to the built-in look until you pick a
color, one **Reset** restores them all, and it's stored in
`state.theme.moneyColors`, saved to Firestore per-user like the rest of
`state.theme`. Category colors in the donut chart / activity icons (e.g.
🍔 Food, 🚗 Transport) are left untouched since those already carry their
own per-category meaning — this only covers the screen's own accents.

## Analytics tab — per-element custom colors (earlier update)

**Setting → 🎨 Theme → Analytics** now has a second card, **Element
colors**, below the existing background/text/size/font/bold controls.
Every distinctly-colored piece of the **Analytics & Insights** panel now
gets its own independent custom-color swatch (pick a preset or use the
color wheel for any hex), instead of only the one shared "Text color":

- Header title ("Analytics & Insights")
- Life Score ring & score number
- Life Score caption
- "Average completion" / "Best day" / "Toughest day" icons & values (one
  swatch each)
- Stat captions (the small text under those three numbers)
- "🧠 Smart Insights" heading
- Smart Insight card accents (overrides the per-card auto color so every
  card matches)
- Section headings ("Daily goal completion…", "Mood trend…", "💰 Money")
- Heatmap squares — recolors the whole Less→More scale from one swatch
  (lighter tints are generated automatically from the color you pick)
- Mood trend line
- "Earned" label & amount
- "Spent" label & amount

Each swatch defaults to the built-in look (empty = unchanged) until you
pick a color, and a **Reset** button (only shown once something's been
changed) restores every one of them at once. Stored in
`state.theme.analyticsColors` and saved to Firestore per-user like the
rest of `state.theme`. Built with the same `ColorSwatchRow` / preset +
custom-picker pattern already used everywhere else in the Theme panel —
no new npm installs required.

## Calendar — text styling + "missed day" mark (earlier update)

Two additions to the Calendar widget:

- **Text Style now works on Calendar too.** In **Layout → Customize
  Layout**, "Calendar" is now tappable in the reorder list right alongside
  Big Goals/Life Rules/Daily·Entry Goals/Earn Money — select it and the
  Text Style panel below (font size, bold, font, color) applies to the
  widget's title, month label, weekday row, and every day number, exactly
  the same mechanism already used by the other free-text widgets.
- **Ended days that weren't finished get a "cut" mark.** Any date that has
  already passed (before today) and never reached 100% completion now
  gets a small red ✕ badge — same animated-draw treatment as the green
  checkmark (two strokes drawn in via `pathLength`), just red and crossed
  instead of a tick, so a glance at the month shows exactly which days
  were completed (✓, green) vs. which ended incomplete (✕, red, and
  slightly faded). Today and future dates are left unmarked since they
  haven't "ended" yet.

## Calendar widget (earlier update)

A new **Calendar** widget — add it like any other dashboard widget via
**Layout → Customize Layout** (drag to reorder, resize, hide/show), and
give it a background color from **Setting → 🎨 Theme → Widgets**, same as
every other tile.

- **One real month at a time** — Sun–Sat grid, correctly aligned to the
  weekday the 1st falls on, no placeholder/fake days.
- **Finished days get a check mark.** Any date already at 100% in
  `state.completionHistory` (the same data the Heatmap/Life Score already
  use) shows an animated green checkmark badge; a day that's partially
  done gets a soft amber fill so progress is visible at a glance.
- **Tiny prev/next controls sit right under the grid** — two small round
  chevron buttons plus a "Today" shortcut, so switching months doesn't
  take up widget space.
- **Smooth animation throughout**: switching months slides the whole grid
  in the direction you navigated (spring physics, not a snap-cut); each
  day cell pops in with a staggered spring entrance; the checkmark badge
  scales in and its tick is drawn stroke-by-stroke via an animated SVG
  path — all `framer-motion`, the same library used everywhere else in
  this dashboard, so it stays visually and technically consistent with
  the rest of the app. No new npm installs required.

*(Note: `animated-component-libraries` / `animejs` / `canvas-design` /
`ckmdesign-system` were considered per the workspace's animation/design
skills, but they're either CDN-script component kits meant for
marketing-site decoration, a general-purpose animation engine that would
duplicate what `framer-motion` already does here, or design-system/canvas
tooling for static art and slide decks — none are a better fit than
extending the same `framer-motion` primitives (spring layout transitions,
`AnimatePresence`, animated SVG `pathLength`) already powering every
other widget's motion in this codebase.)*

## Analytics Summary — customizable metrics, incl. money totals (earlier update)

The **Analytics Summary** dashboard widget (the ring-chart card with Daily
/ Extry / Overall / Day Streak) is no longer a fixed set — it's now fully
editable from **Setting → 🎨 Theme → Analytics Summary**:

- **Add or remove metrics.** Alongside the existing goal-completion rings
  (Daily/Extry/Overall) and Day Streak, you can now add the **money
  totals** — Total Earned, Total Spent, and Net Money — as metric tiles
  right inside the same widget. Anything not wanted can be removed with
  one tap; the widget shrinks/grows around what's left.
- **Reorder by dragging.** Active metrics are a `framer-motion`
  `Reorder.Group` list — drag the grip handle to change the order shown
  on the dashboard.
- **Live preview.** The Theme panel shows the exact same widget component
  used on the dashboard, so what you see while editing is exactly what
  you get.
- **Reset** restores the original Daily/Extry/Overall/Streak default.

Every add, remove, and reorder animates with the same spring physics
(`framer-motion` `AnimatePresence` + `layout` transitions) already used
throughout the app — tiles pop in/out and slide smoothly into the space
freed up by their neighbors, no new npm installs required. Stored in
`state.theme.analyticsSummary.metrics` (an ordered array of metric ids)
and saved to Firestore per-user like the rest of `state.theme`.

## Custom Theme — Dashboard / Analytics / Widgets / Focus Mode (earlier update)

**Setting → 🎨 Theme** is a new tab (next to Add Goles/Add extry/Add Big
Goal/Add Rule) with four independently-styleable sections, each with its
own live preview and a **Reset** button (only shown once you've changed
something):

- **Dashboard** — the overall dashboard's background color + text color
  (5 presets + a custom color picker each). Applies to the main dashboard
  background and every pill/label that doesn't already have its own
  explicit color (widget titles, nav pills, etc. — via a small React
  context so nothing that was deliberately colored before changes).
- **Analytics** — background color, text color, **text size** (85%–140%
  stepper, same A-/A+ control as Text Style), **bold**, and **font**
  (Default/Poppins/Playfair/Mono) for the whole Analytics & Insights tab.
- **Widgets** — a background color swatch (6 presets + custom) *and* a
  Small/Medium/Large size preset, per widget, for all six widgets (Life
  Big Goals, Life Rules, Daily Goals, Entry Goals, Earn Money/Notes,
  Analytics Summary). This is a quick alternative to dragging a corner in
  the Layout tab — both write to the same `state.layout.sizes`, so they
  never conflict.
- **Focus Mode** — background color, text color, text size, bold, and
  font for the Focus Mode screen (same controls as Analytics).

Everything lives in `state.theme` (`dashboard` / `analytics` / `focusMode`
/ `widgets`, each normalized with sane defaults via `normalizeTheme`) and
is saved to Firestore per-user like the rest of the app's state, so it
persists across devices. Built with the same `framer-motion` spring
entrances, swatch pickers and A-/A+ stepper already used by the existing
per-widget **Text Style** feature (below) — visually and technically
consistent, no new npm installs required.

*(Note: the pointer-heavy libraries listed in the initial ask —
`animated-component-libraries`, `animejs`, `aframe-webxr`, `barba-js` —
are meant for marketing-site scrollytelling / WebXR / page-routing
transitions and don't fit a small in-app settings panel; the existing
`framer-motion` (already a project dependency, already used everywhere in
this dashboard) covers every animation this feature needed. Nothing in
`ckmdesign-system` applied here either, since this project already has
its own token set (`C` / `FONT_OPTIONS` / `TEXT_COLOR_OPTIONS`) that this
update extends rather than replaces.)*

## Earn Money / Notes text style (earlier update)

The **Money Today** widget (Earn/Spend labels, notes box, "Today's
Mood" label) is now also selectable in the Text Style panel — tap its
name ("Earn Money / Notes") in the reorder list like any other widget,
and font size / bold / font / color apply to it independently, same
full logic as the other four text widgets. Amount inputs and the
Add/image-upload buttons are left untouched (they're controls, not
content), and the green "Earn"/red "Spend" label colors stay as the
default until you pick a custom color for that widget.

## Per-widget Text Style (earlier update)

Text Style controls now apply to **one widget at a time**, not all four
at once. In **Customize Layout**, tap a widget's name (Life Big Goals,
Life Rules, Daily Goals, or Entry Goals) in the reorder list — it
highlights with an amber border and a small text-icon, and the **Text
Style** panel below switches to editing just that widget (its label
shows next to "Text Style"). Font size / bold / font / color changes
now only affect the selected widget; pick a different one any time to
style it separately, and each widget remembers its own settings
independently (`state.layout.textStyles[widgetId]`).

## Text Style + Hide widgets (earlier update)

**Customize Layout** now has a **Text Style** panel (below the reorder
list) with a live preview and:
- **Font size** — A-/A+ stepper with an animated fill bar, 85%–160%,
  applied to each widget's own base sizes in JS (not a blanket CSS
  scale), so titles/items/subtasks keep their relative proportions
  instead of all flattening to one size.
- **Bold** — a spring-animated toggle switch.
- **Font** — Default (Inter), Poppins, Playfair Display, or Mono
  (JetBrains Mono), loaded via Google Fonts in `app/layout.jsx`.
- **Color** — 5 preset swatches + a custom color picker.

These apply to the free-text widgets: **Life Big Goals, Life Rules,
Daily Goals, Entry Goals**. A **Reset** button (only shown once you've
changed something) restores the defaults.

Every widget (except Analytics Summary, which already had its own
Pin/Unpin) now also has a **Visible / Hidden** eye toggle in the
reorder list, so you can hide any widget from the dashboard without
losing its position or size — toggle it back on any time.

Both settings live in `state.layout.textStyle` / `state.layout.hidden`
and are saved to Firestore per-user like the rest of the layout, so
they persist across devices. Built with `framer-motion` — the same
spring-entrance, whileHover/whileTap micro-interactions already used
throughout Customize Layout — no new npm installs required.

## Filter popup (earlier update)

Money Management now has a **Filter** button (next to Summary/Reset) that
opens a glass popup (Glassmorphism 2.0, spring entrance) with three
multi-select filter groups:
- **Show** — Earn Money / Spend Money (at least one always stays on)
- **Spend category** — all 9 categories, multi-select, with Select all /
  Clear shortcuts (dims out when Spend isn't in "Show")
- **Date range** — All time / Today / 7 / 14 / 30 Days, or a **Custom**
  From–To range

The popup keeps a live "N entries match" count as you toggle filters and
only commits on **Apply Filters**; a filtered view then replaces the
summary strip (Earned/Spent/Net/Entries) and Recent Activity with the
matching totals + a scrollable, image-aware results list, plus a
dismissible "Filtered view · …" chip summarising what's active. The
**Filter** button itself gets an accent badge showing how many filter
groups are active. Built with the same `filterMoneyEntries`/date-preset
helpers reused by both the popup's live preview and the applied view, so
they can never disagree.

## Money popup photos + Reset + Summary (earlier update)

- **Spend Money popup** now also has the optional "📷 Attach a photo"
  dropzone (receipt/bill photo), same as Earn Money already had — pick a
  category *and* optionally attach a photo, then note, then **Done**.
  Every entry's `image` field is stored regardless of type now, and the
  Recent Activity / Summary lists prefer the photo thumbnail over the
  category emoji when one's attached.
- **Money Management → Reset**: a **Reset** button in the header opens a
  glass password popup (same Glassmorphism 2.0 look, spring entrance +
  a shake animation on a wrong attempt). Only the password **`1000`** is
  accepted. On success it wipes `moneyEntries`, `moneyHistory`,
  `totalEarnLife` and `totalSpendLife` — nothing else in state (goals,
  streaks, memories) is touched — and shows a brief "reset ✓" toast.
- **Money Management → Summary**: a **Summary** button opens a large
  glass popup (same date-sidebar layout as the Memories modal) — pick a
  date on the left, see every earn/spend entry logged that day on the
  right with its photo or category icon, note, and ± amount, plus a
  day-total strip (Earned / Spent / Net). Tapping a photo opens the same
  full-screen lightbox used elsewhere in the app.

Built entirely with `framer-motion` (already a project dependency) —
no new npm installs required. `lottie-animations` / Magic UI / Zdog-style
libraries were considered per the workspace's animation skills, but
they're CDN/script-tag tools meant for marketing-site decoration, not a
great fit for small in-app popups; framer-motion's spring physics
(already used everywhere else here, including the hand-rolled tilt-hover
on Memories photos) keeps this update visually and technically
consistent with the rest of the codebase.


This turns your Claude-artifact dashboard into a real, deployable web app:
- **Real Google sign-in** via Firebase Authentication
- **Real database** via Firestore, locked down per-user with security rules
- **Hosting on Vercel** (Firebase here is only Auth + Database, not hosting —
  Next.js app itself deploys to Vercel like normal)

Your dashboard UI, colors, animations, goal/streak logic, analytics — all
unchanged. Only the login screen and the storage layer were swapped.

## Money popup + Money Management tab (this update)

Clicking **Add** next to Earn Money or Spend Money no longer commits the
amount straight away — it opens a glass popup (same Glassmorphism 2.0 /
Liquid Glass look as Memories/Settings, spring entrance animation):

- **Earn Money popup** — shows the amount, then only an optional
  "attach a photo" dropzone (no categories). Tap **Add Earning** to save.
- **Spend Money popup** — shows the amount, then an animated,
  staggered-entrance category grid: **Food, Health, Cloth, Friends,
  Traveling, Shopping, Bills, Entertainment, Other**. Pick one to enable
  **Done**. Both popups also have an optional one-line note field.

Every submission is logged to `state.moneyEntries` (date, type, amount,
category or photo, note) alongside the existing daily `moneyHistory`
aggregate, so nothing about the old totals/charts breaks.

**Analytics → Money Management**: the Analytics tab now shows a compact
"Money Management" nav card (with a live Earned/Spent preview) instead of
the full money chart inline. Tapping it opens a dedicated tab with:
- Summary strip — Total Earned, Total Spent, Net (life), Entries logged
- **Spend by category** — donut chart + ranked list with % share
- **Earn vs spend trend** — the same chart as before, now with a
  7 / 14 / 30-day range toggle
- **Recent activity** — a scrollable feed of every entry (category icon or
  attached photo thumbnail, note, ± amount), newest first

Built entirely with `framer-motion` and `recharts` (both already project
dependencies) — no new npm installs required. Considered
`locomotive-scroll` / `lottie-react` / `vanity-tilt` style libraries per
the workspace's animation skills, but those are script-tag/CDN tools
meant for scrollytelling marketing sites, not a great fit for a small
in-app popup — framer-motion's spring physics (already used everywhere
else in this dashboard) gives the same "professional, glassy, alive"
feel while staying consistent with the rest of the codebase.

## Memories upgrade (earlier update)

The "memor" button now opens a full **Memories** modal instead of a plain text log:

- **Sidebar timeline** — every date you have any activity for (goals, money, mood, photos, notes), newest first.
- **4 tabs per date**: Goals (exactly which Daily/Extry goals you completed that day), Money (earned/spent/net with animated bars), Photos (gallery with a lightweight 3D tilt-hover + full-screen lightbox + download), Notes (that day's saved notes + any memory entries, with an input to add more).
- Glassmorphism styling matches the existing Settings modal, with spring entrance animation, a sliding tab-underline, and staggered list reveals — all built with `framer-motion`, already a project dependency, so **no new npm installs are required**.

### State/data changes that power it
- New `state.dailyLogs[date]` map: `{ images: [dataUrl...], notes, completedGoals: { daily: [...], extry: [...] } }`.
- Toggling a goal now snapshots which goals were done that day into `dailyLogs`, not just the percentage.
- The "Image Upload" button now: (1) resizes/compresses photos client-side to a small JPEG before storing, and (2) keeps up to the last 6 photos **per day** in `dailyLogs`, instead of overwriting a single global `uploadedImage`. This keeps Firestore documents small.
- The daily notes textarea now also mirrors into `dailyLogs[today].notes` so it's visible later in Memories.
- Memory text entries can now be tagged to any date shown in the modal (not only "today").

⚠️ Firestore documents cap at ~1MB — storing many photos across many days as base64 will eventually add up. The compression (480px, JPEG ~0.72 quality) keeps each photo small, but if you use this heavily for months, consider moving images to Firebase Storage later and keeping only URLs in Firestore.

## What changed vs. btl_dashboard.jsx

| Old (artifact) | New (this project) |
|---|---|
| Demo login (name only) | `app/login/page.jsx` — real "Sign in with Google" popup |
| `window.storage` (one shared key, per-Claude-account only) | Firestore doc `btl_state/{uid}` — one document per real user |
| `loadState()` / `saveState()` took no args | Now take the signed-in Firebase `user`, call `lib/btlStorage.js` |
| Nothing enforced auth | `components/AuthGuard.jsx` redirects signed-out users to `/login` |

Everything else in `components/BTLDashboard.jsx` — `GoalChecklist`, `Heatmap`,
`AnalyticsTab`, `SettingsTab`, confetti/shine animations, `CATEGORIES`/
`PRIORITIES` — is untouched.

## Setup steps

### 1. Create a Firebase project
1. Go to https://console.firebase.google.com/ → Add project.
2. Once created: **Build → Authentication → Get started → Sign-in method**
   → enable **Google**.
3. **Build → Firestore Database → Create database** → start in production
   mode (rules below lock it down properly).
4. In **Project settings (gear icon) → General → Your apps** → click the
   `</>` web icon to register a web app → copy the config values shown
   (`apiKey`, `authDomain`, etc.) into your `.env.local` (step 4 below).

### 2. Deploy Firestore security rules
Open **Firestore Database → Rules** in the Firebase console, paste the
contents of `firestore.rules` from this project, and click **Publish**.
This ensures a user can only ever read/write their own `btl_state/{uid}`
document — nobody else's data is reachable, even via the client SDK.

### 3. Authorize your domains (important for Vercel)
Firebase only allows Google sign-in popups from domains you've explicitly
authorized. Go to **Authentication → Settings → Authorized domains** and add:
- `localhost` (usually there by default, for local dev)
- your Vercel domain once deployed, e.g. `btl.vercel.app`
- any custom domain you attach later

If you skip this, Google sign-in will fail on your live Vercel URL with an
`auth/unauthorized-domain` error.

### 4. Configure this project
Your real Firebase config values are already filled into `.env.local` in
this project. If you ever need to regenerate it: `cp .env.local.example
.env.local` and fill in the six `NEXT_PUBLIC_FIREBASE_*` values from step 1.4.

**Note on the API key:** Firebase's web `apiKey` is not a secret — it just
identifies your project to Google's servers; actual access control happens
via the Firestore security rules in step 2, plus Authorized domains in step
3. Still, `.env.local` is git-ignored by default here so you don't
accidentally commit it — add the real values again as Environment Variables
in Vercel (step 6) instead.

### 5. Run locally
```bash
npm install
npm run dev
```
Visit `http://localhost:3000` — you land on `/login`, click "Sign in with
Google", and land on `/dashboard` with data now saved to Firestore.

### 6. Deploy to Vercel
1. Push this folder to a GitHub repo (`.env.local` won't be included —
   it's git-ignored).
2. Go to https://vercel.com → New Project → import the repo.
3. In the project's **Environment Variables**, add:
   ```
   NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSyDXsMSWKzunsIHBLDDcXhhp_2VlqAxi_0Q
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=beyound-the-life.firebaseapp.com
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=beyound-the-life
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=beyound-the-life.firebasestorage.app
   NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=835441355372
   NEXT_PUBLIC_FIREBASE_APP_ID=1:835441355372:web:94f745fd717dc55be00649
   NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID=G-NB91LN3N57
   ```
4. Deploy.
5. Back in Firebase console (step 3 above), add your live
   `*.vercel.app` domain (or custom domain) to **Authorized domains** —
   sign-in won't work until you do this.

## Data migration (optional)
To bring over what's in your artifact's `window.storage`, open the current
artifact and in its browser console run:
```js
const s = await window.storage.get("btl_state_v1", false);
console.log(s.value); // copy this JSON
```
Then, after signing into the new app once (so your Firestore document
exists), go to **Firestore Database → Data → btl_state → your uid**, and
edit the fields to match, or use the Firebase console's "Import" if you
prefer working from the raw JSON.

## ✨ Visual Style (2026 trends)
Direction for the dashboard's look and feel going forward:

- **Purposeful motion** — nothing should just "appear." Cards fold/slide into
  place, buttons soft-expand before releasing on click, and navigation
  elements glide with intent rather than snapping. See [Zeka Design's 2026
  UI/UX trends](https://www.zekagraphic.com/top-10-ui-ux-design-trends-2026/)
  for reference.
- **Soft glass/blur cards** for modals (memory modal, settings) — the
  "Glassmorphism 2.0" / Liquid Glass look, tuned for readability rather than
  pure decoration.
- **Status-aware loading states** — replace generic spinners with states
  that say what's actually happening, e.g. `Saving...` → `Saved ✓` with a
  quick pulse, instead of a bare loading indicator.
- **Customizable widget layout** — the dashboard is a drag-and-reorder,
  resize-and-pin grid of widgets, not a fixed layout. Open the **Layout**
  button in the header to reorder widgets (drag the grip handle), cycle
  each widget's size (Small → Medium → Large — this also controls width
  and height), and pin/unpin the Analytics Summary widget onto the
  dashboard. The arrangement is saved per-user to Firestore, same as the
  rest of the app's state, so it persists across devices and sessions.
  Implemented with `framer-motion`'s `Reorder` API and a 6-column CSS grid
  (`gridAutoFlow: "row dense"`) that reflows automatically as widgets are
  reordered or resized.

**Implementation:** use the animation/UI skills already available in this
workspace rather than hand-rolling motion code:
- `animated-component-libraries` — pre-built animated components (Magic UI /
  React Bits) for things like the glass modals and status pills
- `framer-motion-animator` / `motion-animator` — entrance/exit transitions,
  card fold/slide, button soft-expand, shared layout transitions, and the
  `Reorder` drag-to-reorder API used by the Layout editor
- `gsap-scrolltrigger` — scroll-driven reveals if the dashboard grows
  scrollable sections (e.g. analytics)
- `lightweight-3d-effects` — subtle tilt/parallax touches for hero or
  summary cards, if desired, without pulling in a full 3D engine

## Next steps from the roadmap this unblocks
With Firebase in place, these become notably easier since they're already
part of the same platform:
- **Push notifications** — Firebase Cloud Messaging plugs in directly for
  reminders/streak-break alerts (no separate service needed)
- **PWA** — add a manifest + service worker; Firebase Hosting or Vercel both
  serve it fine
- **Multi-device sync** — already working via this migration
- **Social/leaderboard** — a `streak` leaderboard becomes a Firestore query
  against a separate `leaderboard` collection with relaxed read rules
- **Mobile app (Capacitor/React Native)** — Firebase Auth + Firestore SDKs
  exist natively for both, so most of this backend carries over directly

Say the word and I'll scaffold whichever of these you want next.

## Step 10 — Building the Android APK (Capacitor)

The app now has a native Android wrapper (`android/` folder) via Capacitor,
alongside the existing Vercel website — the two are independent build
targets from the same codebase and don't affect each other.

**App ID / name used:** `com.btl.app` / "Beyond The Life" — this was a
placeholder pick (matches the master spec's example) since it wasn't
confirmed. It's just two lines in `capacitor.config.ts` — say the word and
I'll change it before you do a real signed build (Play Store package IDs
can't be changed after your first upload, so lock this in first).

### How it fits together
- `next.config.js` now has an `output: "export"` mode, but it's **off by
  default** — a plain `npm run build` / Vercel build sees no change at all.
  It only turns on via the `CAPACITOR_BUILD=true` env var, which the new
  `npm run build:capacitor` script sets automatically.
- That static export lands in `out/`, which `npx cap sync android` then
  copies into `android/app/src/main/assets/public` — this is the "offline
  shell" (same pattern as TJRA): the HTML/JS/CSS bundle is baked into the
  APK and loads instantly with no network call, while Firebase Auth and
  Firestore calls still go out live over the internet from inside the
  WebView.
- Audited clean for static export: no `app/api` routes, no server actions,
  no `next/image`, no dynamic route segments — this app was already 100%
  client components, so nothing in `BTLDashboard.jsx` or elsewhere needed
  to change for this to work.

### Building it yourself (needs Android Studio + JDK — not available in this sandbox)
```bash
npm install                  # picks up @capacitor/core, @capacitor/android
npm run cap:sync             # builds the static export + copies it into android/
npm run cap:open             # opens the project in Android Studio
```
From Android Studio: **Build → Build Bundle(s)/APK(s) → Build APK(s)** for a
debug APK, or **Build → Generate Signed Bundle/APK** for a Play-Store-ready
release build (you'll need to create a keystore the first time — Android
Studio walks you through this, and `.gitignore` already excludes `*.keystore`
/ `*.jks` so you never accidentally commit it).

Whenever you change any app code, re-run `npm run cap:sync` before rebuilding
in Android Studio — that's the step that refreshes the bundled web assets.

### ⚠️ Open decision — Google Sign-In inside the APK's WebView
This is the one piece of Step 10 that's a real architecture choice, not just
config, so it's flagged rather than guessed at:

Firebase's web `signInWithPopup` (what `lib/AuthContext.jsx` uses today)
routinely fails inside Capacitor's Android WebView — Google blocks
sign-in popups from embedded WebViews for security reasons. Two ways
forward:
- **Option A — `@capacitor-firebase/authentication` plugin** (recommended):
  swaps in Capacitor's native Google Sign-In on Android specifically, while
  the website keeps using the existing Firebase web popup unchanged — same
  branch-by-platform pattern as the rest of this redesign. Slightly more
  setup (SHA-1 fingerprint registered in Firebase console, `google-services.json`
  added to `android/app/`).
  Docs: https://github.com/capawesome-team/capacitor-firebase
- **Option B — ship it as-is and test first**: some newer WebView/Play
  Services combos do let the popup flow work; it's worth trying a debug
  APK before adding a new dependency. If sign-in fails on-device, fall back
  to Option A.

Tell me which you'd like and I'll wire it up next — Option A needs a
`google-services.json` file from your Firebase console (Project Settings →
your Android app → download it) before I can finish the plugin setup.
